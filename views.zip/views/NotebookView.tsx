import React, { useEffect, useRef, useState } from 'react';
import { useData } from '../services/dataContext';
import { NotebookCellView } from '../components/NotebookCell';
import { Plus, Database, Eraser, ShieldCheck, Activity, Terminal, Download, X, History, FileText } from 'lucide-react';
import { NotebookCell } from '../types';

export const NotebookView: React.FC = () => {
  const { cells, addCell, lineage, dataState } = useData();
  const endRef = useRef<HTMLDivElement>(null);
  const [showSandbox, setShowSandbox] = useState(false);

  useEffect(() => {
      // Auto-scroll to bottom when new cell added
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [cells.length]);

  const handleAddCell = (type: NotebookCell['type']) => {
      addCell(type);
  };

  const handleExportExecutiveSummary = () => {
      const printWindow = window.open('', '_blank');
      if (!printWindow) return;

      const ingestCell = cells.find(c => c.type === 'ingest' && c.status === 'done');
      const dataset = Object.values(dataState.datasets)[0];
      const aiUnderstanding = ingestCell?.aiUnderstanding;

      const htmlContent = `
        <html>
          <head>
            <title>Executive Summary - DataWise</title>
            <style>
              body { font-family: 'Georgia', serif; padding: 60px; color: #111; line-height: 1.6; max-width: 800px; margin: 0 auto; }
              h1 { font-family: 'Arial', sans-serif; font-size: 32px; border-bottom: 3px solid #000; padding-bottom: 20px; margin-bottom: 40px; }
              h2 { font-family: 'Arial', sans-serif; font-size: 20px; color: #333; margin-top: 40px; border-bottom: 1px solid #ddd; padding-bottom: 8px; }
              .meta { color: #666; font-style: italic; margin-bottom: 40px; }
              .stat-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
              .stat-box { background: #f5f5f5; padding: 15px; border-radius: 4px; text-align: center; }
              .stat-val { font-size: 24px; font-weight: bold; display: block; }
              .stat-label { font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: #666; }
              .correction { background: #fff5f5; border-left: 4px solid #ef4444; padding: 15px; margin: 20px 0; font-size: 14px; }
              .finding { background: #f0fdf4; border-left: 4px solid #22c55e; padding: 15px; margin: 10px 0; }
              ul { padding-left: 20px; }
              li { margin-bottom: 8px; }
            </style>
          </head>
          <body>
            <h1>Executive Data Analysis Summary</h1>
            <div class="meta">
                Generated on ${new Date().toLocaleDateString()} for Session ID: ${ingestCell?.id.split('_')[1] || 'Unknown'} <br/>
                Analyst: Senior AI Analyst (DataWise)
            </div>

            <h2>1. Objective</h2>
            <p>The primary objective of this analysis was to profile, clean, and explore the uploaded dataset to derive actionable insights. 
            The system identified the data as <strong>${aiUnderstanding?.domainGuess || 'General Purpose'}</strong>.</p>

            <h2>2. Data Overview</h2>
            <div class="stat-grid">
                <div class="stat-box">
                    <span class="stat-val">${dataset?.rowCount.toLocaleString() || 0}</span>
                    <span class="stat-label">Total Records</span>
                </div>
                <div class="stat-box">
                    <span class="stat-val">${dataset?.columns.length || 0}</span>
                    <span class="stat-label">Columns</span>
                </div>
                <div class="stat-box">
                    <span class="stat-val">${aiUnderstanding?.confidence || 'N/A'}</span>
                    <span class="stat-label">AI Confidence</span>
                </div>
            </div>
            <p><strong>Source:</strong> ${ingestCell?.input?.replace('Load file: ', '') || 'External Source'}</p>
            <p><strong>Key Identifiers:</strong> ${aiUnderstanding?.keyIdentifiers.join(', ') || 'None detected'}</p>

            <h2>3. Analytical Steps Performed</h2>
            <ul>
                ${cells.filter(c => c.status === 'done').map(c => `
                    <li><strong>${c.type.toUpperCase().replace('_', ' ')}:</strong> ${c.input || c.plan?.intent || 'Executed successfully'}</li>
                `).join('')}
            </ul>

            <h2>4. Key Findings</h2>
            ${cells.filter(c => c.type.startsWith('eda_') && c.status === 'done').map(c => `
                <div class="finding">
                    <strong>${c.type.split('_')[1].toUpperCase()}:</strong> ${c.output?.stats?.correlation ? `Correlation coefficient: ${c.output.stats.correlation}` : 'Analysis completed.'}
                    <br/>${c.plan?.rationale || ''}
                </div>
            `).join('') || '<p>No exploratory analysis findings recorded yet.</p>'}

            <h2>5. User Interventions & Corrections</h2>
            ${lineage.length > 0 ? lineage.map(l => `
                <div class="correction">
                    <strong>${l.type === 'user_correction' ? 'User Correction' : 'AI Action'}:</strong> ${l.description}
                    ${l.rationale ? `<br/><em>Rationale: ${l.rationale}</em>` : ''}
                </div>
            `).join('') : '<p>No major user corrections were required. The AI process was approved at all stages.</p>'}

            <h2>6. Final Confidence Statement</h2>
            <p>Based on the validation checks and user feedback, the confidence in these results is <strong>${aiUnderstanding?.userConfirmed ? 'HIGH' : 'MEDIUM'}</strong>. 
            All critical assumptions regarding ${aiUnderstanding?.domainGuess} logic have been ${aiUnderstanding?.userConfirmed ? 'verified' : 'noted'}.</p>
            
            <script>window.print();</script>
          </body>
        </html>
      `;
      
      printWindow.document.write(htmlContent);
      printWindow.document.close();
  };

  const handlePrintLineage = () => {
      const printWindow = window.open('', '_blank');
      if (!printWindow) return;

      // 1. NLP-based Data Understanding
      const ingestCell = cells.find(c => c.type === 'ingest' && c.status === 'done');
      let aiUnderstanding = "No data loaded yet.";
      
      if (ingestCell?.output?.outputs) {
          const ds = Object.values(ingestCell.output.outputs)[0] as any;
          const colNames = ds.columns.map((c: any) => c.name.toLowerCase());
          
          let domain = "general purpose";
          if (colNames.some((c: string) => c.includes('price') || c.includes('amount') || c.includes('sales'))) domain = "financial/transactional";
          else if (colNames.some((c: string) => c.includes('email') || c.includes('customer') || c.includes('user'))) domain = "customer relationship (CRM)";
          else if (colNames.some((c: string) => c.includes('sensor') || c.includes('temp') || c.includes('device'))) domain = "IoT/Telemetry";

          const sourceType = ingestCell.input?.toLowerCase();
          let sourceDesc = "an unknown source";
          if (sourceType?.includes('file')) sourceDesc = "a <strong>Local CSV/Excel File</strong>";
          else if (sourceType?.includes('warehouse')) sourceDesc = "the <strong>Enterprise Data Warehouse</strong>";
          else if (sourceType?.includes('lake') || sourceType?.includes('s3')) sourceDesc = "the <strong>Data Lake (S3)</strong>";
          else if (sourceType?.includes('streaming') || sourceType?.includes('kafka')) sourceDesc = "a <strong>Real-time Kafka Stream</strong>";

          aiUnderstanding = `
              <p>I have analyzed the dataset ingested from ${sourceDesc}. It consists of <strong>${ds.rowCount.toLocaleString()} rows</strong> and <strong>${ds.columns.length} columns</strong>.</p>
              <p>Based on the schema (containing fields like <em>${ds.columns.slice(0, 3).map((c: any) => c.name).join(', ')}</em>), I interpret this as <strong>${domain} data</strong>. 
              The initial structural scan confirms the data is ${ds.rowCount > 1000 ? 'statistically significant' : 'a small sample'} and suitable for analysis.</p>
          `;
      }

      const htmlContent = `
        <html>
          <head>
            <title>Data Lineage Report - DataWise</title>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; padding: 40px; color: #1f2937; line-height: 1.6; max-width: 900px; margin: 0 auto; }
              h1 { border-bottom: 2px solid #111827; padding-bottom: 16px; margin-bottom: 8px; font-size: 28px; letter-spacing: -0.5px; }
              .header { margin-bottom: 40px; color: #6b7280; font-size: 14px; }
              
              .section-title { font-size: 18px; font-weight: 700; margin-top: 40px; margin-bottom: 16px; color: #111827; display: flex; align-items: center; gap: 8px; }
              .ai-summary { background: #f9fafb; border: 1px solid #e5e7eb; padding: 24px; border-radius: 12px; margin-bottom: 32px; }
              .ai-summary h3 { margin-top: 0; font-size: 14px; text-transform: uppercase; color: #6b7280; letter-spacing: 0.05em; }
              
              .timeline { position: relative; border-left: 2px solid #e5e7eb; margin-left: 16px; padding-left: 32px; }
              .cell-node { position: relative; margin-bottom: 40px; }
              .cell-node::before { content: ''; position: absolute; left: -41px; top: 0; width: 16px; height: 16px; border-radius: 50%; background: #fff; border: 4px solid #d1d5db; }
              .cell-node.clean::before { border-color: #3b82f6; }
              .cell-node.eda::before { border-color: #eab308; }
              .cell-node.validate::before { border-color: #10b981; }
              
              .meta { font-size: 11px; font-weight: 700; color: #9ca3af; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px; }
              h4 { margin: 0 0 8px 0; font-size: 16px; font-weight: 600; }
              
              .nlp-box { background: #fff; border: 1px solid #e5e7eb; padding: 16px; border-radius: 8px; font-size: 14px; color: #374151; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
              .nlp-box strong { color: #111827; }
              .tag { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; }
              .tag.clean { background: #eff6ff; color: #1d4ed8; }
              .tag.eda { background: #fffbeb; color: #b45309; }
              .tag.val { background: #ecfdf5; color: #047857; }

              .suggestions { background: #f5f3ff; border: 1px dashed #7c3aed; padding: 24px; border-radius: 12px; margin-top: 40px; }
              .suggestions h3 { color: #5b21b6; margin-top: 0; }
              .suggestions ul { padding-left: 20px; color: #4c1d95; font-size: 14px; }
              .suggestions li { margin-bottom: 8px; }
            </style>
          </head>
          <body>
            <h1>DataWise Lineage & History Report</h1>
            <div class="header">Generated on ${new Date().toLocaleString()} • Session ID: ${Math.random().toString(36).substring(7)}</div>
            
            <div class="ai-summary">
                <h3>AI Data Understanding</h3>
                ${aiUnderstanding}
                <p>I have successfully tracked and executed <strong>${cells.filter(c => c.status === 'done').length} steps</strong> in this session. The workflow demonstrates a clear progression from raw data ingestion to structural validation and exploratory analysis.</p>
            </div>

            <div class="section-title">Execution Narrative</div>
            <div class="timeline">
            ${cells.filter(c => c.status === 'done' || c.status === 'approved').map(cell => {
                let typeClass = '';
                let content = '';
                let tag = '';
                
                if (cell.type === 'ingest') {
                    typeClass = 'ingest';
                    tag = '<span class="tag">Ingestion</span>';
                    content = `I successfully established a connection to the source and ingested the raw data. Schema inference was performed automatically, identifying data types for all columns.`;
                } else if (cell.type === 'cleaning_step') {
                    typeClass = 'clean';
                    tag = '<span class="tag clean">Data Cleaning</span>';
                    content = `
                        <strong>Observation:</strong> I detected anomalies in the <code>${cell.plan?.proposed_steps[0]?.params?.column || 'target'}</code> column that could impact analysis quality.<br/><br/>
                        <strong>Action Taken:</strong> I applied a transformation to ${cell.plan?.proposed_steps[0]?.description.toLowerCase() || 'clean the data'}.<br/><br/>
                        <strong>Result:</strong> The data is now standardized, ensuring consistency for downstream tasks.
                    `;
                } else if (cell.type === 'validation') {
                    typeClass = 'validate';
                    tag = '<span class="tag val">Validation</span>';
                    content = `I ran a comprehensive quality check against ${cell.output?.validation?.steps_validated || 0} predefined rules. <strong>All assertions passed</strong>, confirming that the dataset meets the required integrity standards.`;
                } else if (cell.type.startsWith('eda_')) {
                    typeClass = 'eda';
                    tag = '<span class="tag eda">EDA Analysis</span>';
                    const analysisType = cell.type.split('_')[1];
                    let insight = "Analysis generated successfully.";
                    
                    if (analysisType === 'correlation') insight = "The correlation matrix highlights potential relationships between numeric variables. Strong correlations (positive or negative) may indicate redundancy.";
                    if (analysisType === 'distribution') insight = "The distribution plot reveals the spread and central tendency of the data. I checked for skewness and potential normality.";
                    if (analysisType === 'outlier') insight = "I used the Interquartile Range (IQR) method to detect statistical outliers. These data points deviate significantly from the norm.";
                    
                    content = `I performed a <strong>${analysisType} analysis</strong> to understand the data's statistical properties. <br/><br/><strong>AI Interpretation:</strong> ${insight}`;
                }

                return `
                    <div class="cell-node ${typeClass}">
                        <div class="meta">${new Date(cell.timestamp).toLocaleTimeString()}</div>
                        ${tag}
                        <div class="nlp-box">
                            ${content}
                        </div>
                    </div>
                `;
            }).join('')}
            </div>

            <div class="suggestions">
                <h3>AI Recommendations</h3>
                <ul>
                    <li><strong>Data Governance:</strong> Since this dataset contains ${ingestCell?.input?.includes('file') ? 'manual uploads' : 'enterprise data'}, I recommend registering it in the Data Catalog for governance.</li>
                    <li><strong>Optimization:</strong> The data volume is manageable, but for larger datasets (>1M rows), consider switching to the Spark execution engine.</li>
                    <li><strong>Next Best Action:</strong> With cleaning and EDA complete, you are ready to build a <strong>Predictive Model</strong> or export the <strong>Cleaned Dataset</strong> to the warehouse.</li>
                </ul>
            </div>

            <script>window.print();</script>
          </body>
        </html>
      `;

      printWindow.document.write(htmlContent);
      printWindow.document.close();
  };

  const generateScript = () => {
      let script = `
# DataWise Analyst-Grade AI Script
# Session: ${new Date().toISOString()}

# ==========================================
# 1. CORE DATA & COMPUTE (Truth Layer)
# ==========================================
import pandas as pd          # tabular manipulation
import numpy as np           # numerical operations
import pyarrow as pa         # schema + memory safety
import duckdb                # SQL-grade aggregation engine

# ==========================================
# 2. SEMANTIC & COLUMN INTELLIGENCE
# ==========================================
from rapidfuzz import fuzz     # column intent similarity
import re                      # name pattern detection
from pandas.api.types import (
    is_numeric_dtype,
    is_datetime64_any_dtype
)

# Semantic Roles
COLUMN_ROLES = {
    "identifier",
    "metric_additive",
    "metric_ratio",
    "dimension",
    "time"
}

def infer_column_role(df, col):
    name = col.lower()
    if "id" in name or name.endswith("_key"):
        return "identifier"
    if any(k in name for k in ["amount", "price", "revenue", "sales", "cost"]):
        return "metric_additive"
    if any(k in name for k in ["rate", "percent", "pct", "ratio", "avg"]):
        return "metric_ratio"
    if is_datetime64_any_dtype(df[col]) or "date" in name or "time" in name:
        return "time"
    if is_numeric_dtype(df[col]):
        # Fallback for unlabeled numerics
        return "metric_additive" 
    return "dimension"

# ==========================================
# 3. EDA INTENT & CONSTRAINT ENGINE
# ==========================================
EDA_INTENTS = {
    "distribution": { "charts": ["histogram", "density"], "aggregation": "count" },
    "magnitude": { "charts": ["kpi", "bar"], "aggregation": ["sum", "mean"] },
    "comparison": { "charts": ["bar", "box"], "x": "dimension", "y": "metric" },
    "trend": { "charts": ["line"], "x": "time", "y": "metric" },
    "relationship": { "charts": ["scatter"], "x": "metric", "y": "metric" }
}

# ==========================================
# 4. STATISTICS & ANALYTICS
# ==========================================
import scipy.stats as stats
import statsmodels.api as sm
from sklearn.preprocessing import StandardScaler

# ==========================================
# 5. VISUALIZATION
# ==========================================
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# ==========================================
# 6. LINEAGE & AUDIT
# ==========================================
import json
from datetime import datetime

audit_log = []

def log_step(step, intent, details):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "step": step,
        "intent": intent,
        "details": details,
        "confirmed_by_user": True
    }
    audit_log.append(entry)
    print(f"AUDIT: {json.dumps(entry)}")

# ==========================================
# EXECUTION FLOW
# ==========================================

`;
      
      cells.forEach(cell => {
          if (cell.status !== 'done') return;

          if (cell.type === 'ingest' && cell.output?.outputs) {
              const dsName = Object.keys(cell.output.outputs)[0] || 'dataset';
              script += `# [Step ${cell.id}] LOAD & VALIDATE\n`;
              script += `df = pd.read_csv('uploaded_file.csv')\n`;
              script += `print(f"Loaded {df.shape[0]} rows, {df.shape[1]} columns")\n`;
              script += `\n# Semantic Inference\ncolumn_semantics = { col: infer_column_role(df, col) for col in df.columns }\nprint("Semantics:", column_semantics)\n\n`;
          }
          
          if (cell.type === 'eda_menu' && cell.chartProposal) {
               const { intent, scope, chartType, xAxis, yAxis } = cell.chartProposal;
               script += `# [Step ${cell.id}] USER-CONFIRMED EDA INTENT: ${intent?.toUpperCase()}\n`;
               script += `eda_intent = "${intent}"\n`;
               script += `rules = EDA_INTENTS[eda_intent]\n`;
               
               if (xAxis.column && yAxis.column) {
                   script += `\n# Safe Aggregation (DuckDB)\n`;
                   script += `if column_semantics["${yAxis.column}"] in ["metric_additive", "metric_ratio"]:\n`;
                   if (yAxis.aggregation !== 'none') {
                       script += `    query = "SELECT ${xAxis.column}, ${yAxis.aggregation.toUpperCase()}(${yAxis.column}) as val FROM df GROUP BY ${xAxis.column}"\n`;
                       script += `    df_agg = duckdb.query(query).to_df()\n`;
                       script += `    # Visualization\n`;
                       script += `    px.${chartType}(df_agg, x='${xAxis.column}', y='val', title='${intent} Analysis').show()\n`;
                   } else {
                        script += `    px.${chartType}(df, x='${xAxis.column}', y='${yAxis.column}', title='${intent} Analysis').show()\n`;
                   }
                   script += `\nlog_step("EDA", "${intent}", {"x": "${xAxis.column}", "y": "${yAxis.column}", "chart": "${chartType}"})\n\n`;
               }
          }
      });

      return script;
  };

  const handleCopyScript = () => {
      const script = generateScript();
      navigator.clipboard.writeText(script);
      alert("Script copied to clipboard!");
  };

  const handleDownloadScript = () => {
      const script = generateScript();
      const blob = new Blob([script], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `datawise_script_${new Date().toISOString().split('T')[0]}.py`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  return (
    <div className="h-full flex flex-col bg-zinc-950 relative">
      <div className="flex-1 overflow-y-auto p-8 scroll-smooth">
          <div className="max-w-4xl mx-auto pb-20">
              <div className="mb-8 text-center relative">
                  <h1 className="text-2xl font-bold text-white mb-2">DataWise Local AI Notebook</h1>
                  <p className="text-zinc-500 text-sm">Interactive AI-powered data analysis. Add a cell to begin.</p>
                  
                  <button 
                      onClick={() => setShowSandbox(true)}
                      className="absolute top-0 right-0 text-zinc-400 hover:text-white flex items-center gap-2 text-xs font-bold border border-zinc-800 hover:border-green-500 px-3 py-2 rounded-lg bg-zinc-900 transition-all"
                  >
                      <Terminal size={14} className="text-green-500" /> Script
                  </button>
              </div>

              {cells.map(cell => (
                  <NotebookCellView key={cell.id} cell={cell} />
              ))}
              
              <div ref={endRef} />

              {/* Add Cell Controls */}
              <div className="mt-8 border-t border-dashed border-zinc-800 pt-8">
                  <div className="flex justify-center gap-2 mb-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">
                      Add New Cell
                  </div>
                  <div className="flex flex-wrap justify-center gap-3">
                      <button onClick={() => handleAddCell('ingest')} className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 hover:border-violet-500 hover:text-violet-400 rounded-lg text-xs font-bold transition-all group">
                          <Database size={16} className="text-zinc-500 group-hover:text-violet-500" /> Load Data
                      </button>
                      <button onClick={() => handleAddCell('clean')} className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 hover:border-blue-500 hover:text-blue-400 rounded-lg text-xs font-bold transition-all group">
                          <Eraser size={16} className="text-zinc-500 group-hover:text-blue-500" /> Clean
                      </button>
                      <button onClick={() => handleAddCell('validation')} className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 hover:border-green-500 hover:text-green-400 rounded-lg text-xs font-bold transition-all group">
                          <ShieldCheck size={16} className="text-zinc-500 group-hover:text-green-500" /> Validate
                      </button>
                      <button onClick={() => handleAddCell('eda')} className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 hover:border-yellow-500 hover:text-yellow-400 rounded-lg text-xs font-bold transition-all group">
                          <Activity size={16} className="text-zinc-500 group-hover:text-yellow-500" /> EDA Analysis
                      </button>
                      <button onClick={() => handleAddCell('export')} className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-500 hover:text-white rounded-lg text-xs font-bold transition-all group">
                          <Download size={16} className="text-zinc-500 group-hover:text-white" /> Export
                      </button>
                  </div>
              </div>
          </div>
      </div>

      {/* Code Sandbox Modal */}
      {showSandbox && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-8 backdrop-blur-sm animate-fade-in">
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl w-full max-w-4xl h-[80vh] flex flex-col shadow-2xl overflow-hidden">
                <div className="flex justify-between items-center p-4 border-b border-zinc-800 bg-zinc-900">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-black flex items-center justify-center border border-zinc-800">
                            <Terminal size={16} className="text-green-500"/>
                        </div>
                        <div>
                            <div className="text-sm font-bold text-white">Python Script Sandbox</div>
                            <div className="text-xs text-zinc-500">Auto-generated from your notebook actions</div>
                        </div>
                    </div>
                    <button onClick={() => setShowSandbox(false)} className="p-2 hover:bg-zinc-800 rounded text-zinc-500 hover:text-white transition-colors"><X size={18}/></button>
                </div>
                <div className="flex-1 p-0 overflow-auto bg-[#0d1117]">
                    <div className="flex min-h-full">
                        <div className="w-12 bg-[#0d1117] border-r border-zinc-800/50 flex flex-col items-end py-4 pr-2 select-none">
                             {generateScript().split('\n').map((_, i) => (
                                 <div key={i} className="text-[10px] text-zinc-700 font-mono leading-relaxed">{i + 1}</div>
                             ))}
                        </div>
                        <pre className="flex-1 p-4 font-mono text-xs text-zinc-300 leading-relaxed whitespace-pre-wrap selection:bg-green-900/30">
                            {generateScript().split('\n').map((line, i) => (
                                <div key={i}>
                                    {line.startsWith('#') ? <span className="text-zinc-500">{line}</span> : 
                                     line.includes('import') ? <span className="text-violet-400">{line}</span> :
                                     line.includes('df') || line.includes('fig') ? <span className="text-blue-300">{line}</span> :
                                     <span className="text-zinc-300">{line}</span>}
                                </div>
                            ))}
                        </pre>
                    </div>
                </div>
                <div className="p-4 border-t border-zinc-800 bg-zinc-900 flex justify-end gap-3">
                    <button onClick={handleCopyScript} className="px-4 py-2 bg-black border border-zinc-800 hover:border-zinc-600 text-white text-xs font-bold rounded-lg transition-all">Copy to Clipboard</button>
                    <button onClick={handleDownloadScript} className="px-4 py-2 bg-green-600 hover:bg-green-500 text-white text-xs font-bold rounded-lg flex items-center gap-2 shadow-lg shadow-green-900/20 transition-all">
                        <Download size={14}/> Download Script
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
