import React, { useEffect, useState, useRef } from 'react';
import { AppMode, TableSchema, OutlierResult, EDAIntent, ChartProposal } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend, ScatterChart, Scatter, ZAxis, Histogram } from 'recharts';
import { FileBarChart, PieChart, Activity, AlertOctagon, Grid, CheckCircle, Play, Calendar, MapPin, Clock, ShoppingCart, Plus, Trash2, ChevronDown, ChevronRight, Bug, Info, ArrowRight, Brain } from 'lucide-react';
import { mockDetectOutliers, mockGetDistribution, mockGetMonthlyTrends, mockGetHourlyTrends, mockGetSegments, mockGetColumnStats, mockGetScatterData } from '../services/mockApi';
import { useData } from '../services/dataContext';
import { detectColumnRole, getSmartAggregation, generateEDAProposal } from '../services/semanticLayer';

interface EdaViewProps {
  activeTable: TableSchema;
  appMode: AppMode;
}

type CellType = 'univariate' | 'bivariate' | 'monthly' | 'hourly' | 'city' | 'products' | 'outliers';

interface EdaCell {
  id: string;
  type: CellType;
  title: string;
  status: 'draft' | 'planning' | 'waiting_confirmation' | 'executing' | 'done' | 'error';
  config: {
    xCol?: string;
    yCol?: string;
    intent?: EDAIntent; // Added Intent
    chartType?: string; // Added Chart Type
    aggregation?: string; // Added Aggregation
    overrideReason?: string; // For user correction
  };
  reasoning?: string;
  proposal?: ChartProposal; // Stores the AI's proposal
  stats?: any; 
  result?: any;
  error?: string;
}

export const EdaView: React.FC<EdaViewProps> = ({ activeTable, appMode }) => {
  const { dataState, addToHistory } = useData();
  const [cells, setCells] = useState<EdaCell[]>([]);
  const [debugMode, setDebugMode] = useState(false);
  const [semanticProfile, setSemanticProfile] = useState<any>(null); // Store profile

  // 1. DATASET SEMANTIC PROFILING (RUN ON LOAD)
  useEffect(() => {
    if (activeTable) {
        const profile: any = {};
        activeTable.columns.forEach(col => {
            const role = detectColumnRole(col.name, col.type);
            profile[col.name] = {
                type: col.type,
                role: role,
                aggregation_safe: role !== 'identifier',
                default_aggregation: getSmartAggregation(role)
            };
        });
        setSemanticProfile(profile);
        console.log("Semantic Profile Generated:", profile);
    }
  }, [activeTable]);
  
  useEffect(() => {
      if (cells.length === 0) {
          addCell('univariate', 'Univariate Distribution');
      }
  }, []);

  const addCell = (type: CellType, title: string) => {
      const newCell: EdaCell = {
          id: Math.random().toString(36).substr(2, 9),
          type,
          title,
          status: 'draft',
          config: {}
      };
      setCells(prev => [...prev, newCell]);
      setTimeout(() => {
          document.getElementById(newCell.id)?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
  };

  const removeCell = (id: string) => {
      setCells(prev => prev.filter(c => c.id !== id));
  };

  const updateCell = (id: string, updates: Partial<EdaCell>) => {
      setCells(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  // 3. EDA INTENT ENGINE & 4. CHART DECISION MATRIX
  const runCellPlanning = async (cell: EdaCell) => {
      updateCell(cell.id, { status: 'planning' });
      
      await new Promise(resolve => setTimeout(resolve, 600));
      
      // Determine Intent based on cell type (mapping legacy UI to new engine)
      let intent: EDAIntent = 'distribution';
      if (cell.type === 'bivariate') intent = 'relationship';
      if (cell.type === 'monthly' || cell.type === 'hourly') intent = 'trend';
      if (cell.type === 'city' || cell.type === 'products') intent = 'comparison';
      if (cell.type === 'outliers') intent = 'outliers';

      // 5. PRE-FLIGHT VALIDATION (Part of Proposal Generation)
      try {
          const dataset = { ...activeTable, rowCount: 1000 }; // Mock dataset object
          const proposal = generateEDAProposal(
              dataset, 
              cell.type === 'univariate' ? 'univariate' : 'bivariate', 
              intent,
              cell.config.xCol,
              cell.config.yCol
          );

          updateCell(cell.id, { 
              status: 'waiting_confirmation', 
              proposal,
              reasoning: proposal.rationale,
              config: {
                  ...cell.config,
                  intent,
                  chartType: proposal.chartType,
                  aggregation: proposal.yAxis.aggregation
              }
          });

      } catch (err: any) {
           updateCell(cell.id, { status: 'error', error: err.message });
      }
  };

  const executeCell = async (cell: EdaCell) => {
      updateCell(cell.id, { status: 'executing' });
      
      try {
          let result = null;
          // Legacy mock calls mapped to new Intent structure
          if (cell.config.intent === 'distribution' && cell.config.xCol) {
              result = await mockGetDistribution(activeTable.tableName, cell.config.xCol);
          } else if (cell.config.intent === 'trend' && cell.config.xCol) {
              if (cell.type === 'hourly') result = await mockGetHourlyTrends(activeTable.tableName, cell.config.xCol);
              else result = await mockGetMonthlyTrends(activeTable.tableName, cell.config.xCol, cell.config.yCol || 'amount');
          } else if (cell.config.intent === 'comparison' && cell.config.xCol) {
              result = await mockGetSegments(activeTable.tableName, cell.config.xCol, cell.config.yCol || 'amount');
          } else if (cell.config.intent === 'relationship' && cell.config.xCol && cell.config.yCol) {
              result = await mockGetScatterData(activeTable.tableName, cell.config.xCol, cell.config.yCol);
          } else if (cell.config.intent === 'outliers') {
              const res = await mockDetectOutliers(activeTable.tableName);
              result = res.filter(r => r.column === cell.config.xCol);
          }

          if (!result || (Array.isArray(result) && result.length === 0)) {
              throw new Error("No data found for this selection.");
          }

          updateCell(cell.id, { status: 'done', result });

          // 9. LINEAGE LOGGING
          addToHistory({
              user: 'Admin',
              action: 'analysis',
              description: `EDA: ${cell.title}`,
              versionId: `v${Date.now()}`,
              codeSnapshot: `Intent: ${cell.config.intent} | Chart: ${cell.config.chartType} | Agg: ${cell.config.aggregation}`,
              ai_rationale: cell.proposal?.rationale,
              user_prompt: `Analyze ${cell.config.intent} of ${cell.config.xCol}`
          });

      } catch (e: any) {
          updateCell(cell.id, { status: 'error', error: e.message });
      }
  };

  // 8. USER CORRECTION LOOP
  const handleCorrection = (cell: EdaCell, field: string, value: string) => {
      // Allow user to override AI assumptions
      updateCell(cell.id, { 
          config: { ...cell.config, [field]: value },
          reasoning: `User manually overrode ${field} to ${value}.` 
      });
  };

  const renderCell = (cell: EdaCell) => {
      return (
          <div id={cell.id} className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden mb-8 transition-all hover:border-zinc-700">
              <div className="px-6 py-4 bg-zinc-950/50 border-b border-zinc-800 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                      <div className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider ${
                          cell.status === 'done' ? 'bg-green-900/30 text-green-400' : 
                          cell.status === 'error' ? 'bg-red-900/30 text-red-400' : 'bg-blue-900/30 text-blue-400'
                      }`}>
                          {cell.type}
                      </div>
                      <span className="font-bold text-zinc-200">{cell.title}</span>
                  </div>
                  <button onClick={() => removeCell(cell.id)} className="text-zinc-600 hover:text-red-400 transition-colors"><Trash2 size={16} /></button>
              </div>

              <div className="p-6">
                  {/* CONFIGURATION UI */}
                  <div className="flex flex-wrap gap-4 mb-6">
                      {(cell.type === 'univariate' || cell.type === 'bivariate' || cell.type === 'monthly' || cell.type === 'hourly' || cell.type === 'city' || cell.type === 'products' || cell.type === 'outliers') && (
                          <div className="flex items-center gap-2">
                              <span className="text-xs text-zinc-500 font-bold uppercase">
                                  {cell.type === 'monthly' || cell.type === 'hourly' ? 'Time Column' : 'Column X'}
                              </span>
                              <select 
                                  value={cell.config.xCol || ''}
                                  onChange={(e) => updateCell(cell.id, { config: { ...cell.config, xCol: e.target.value }, status: 'draft' })}
                                  className="bg-black border border-zinc-700 text-sm text-white rounded px-3 py-1.5 focus:outline-none focus:border-violet-500"
                              >
                                  <option value="">Select...</option>
                                  {activeTable.columns.map(c => <option key={c.name} value={c.name}>{c.name} ({c.type})</option>)}
                              </select>
                          </div>
                      )}
                      
                      {(cell.type === 'bivariate' || cell.type === 'monthly' || cell.type === 'city' || cell.type === 'products') && (
                          <div className="flex items-center gap-2">
                              <span className="text-xs text-zinc-500 font-bold uppercase">
                                  {cell.type === 'city' || cell.type === 'products' ? 'Metric' : 'Column Y'}
                              </span>
                              <select 
                                  value={cell.config.yCol || ''}
                                  onChange={(e) => updateCell(cell.id, { config: { ...cell.config, yCol: e.target.value }, status: 'draft' })}
                                  className="bg-black border border-zinc-700 text-sm text-white rounded px-3 py-1.5 focus:outline-none focus:border-violet-500"
                              >
                                  <option value="">Select...</option>
                                  {activeTable.columns.filter(c => ['INTEGER', 'FLOAT', 'DOUBLE', 'NUMERIC'].includes(c.type)).map(c => (
                                      <option key={c.name} value={c.name}>{c.name}</option>
                                  ))}
                              </select>
                          </div>
                      )}

                      {cell.status === 'draft' && (
                          <button 
                              onClick={() => runCellPlanning(cell)}
                              disabled={!cell.config.xCol}
                              className="ml-auto bg-zinc-800 hover:bg-violet-600 text-white px-4 py-1.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                              Generate Plan
                          </button>
                      )}
                  </div>

                  {/* 6. EDA UI FIX - INTENT SUMMARY */}
                  {(cell.status === 'planning' || cell.status === 'waiting_confirmation' || cell.status === 'executing' || cell.status === 'done') && cell.proposal && (
                      <div className="mb-6 bg-zinc-950/50 border border-zinc-800 rounded-lg p-4 animate-fade-in">
                          <div className="flex items-start gap-3">
                              <div className="mt-1"><Brain size={16} className="text-violet-500" /></div>
                              <div className="flex-1 w-full">
                                  <div className="flex justify-between items-start mb-2">
                                      <h4 className="text-sm font-bold text-violet-200">AI Analysis Plan</h4>
                                      <div className="px-2 py-0.5 rounded bg-violet-900/30 border border-violet-900/50 text-violet-300 text-[10px] font-bold uppercase">
                                          {cell.proposal.confidence} Confidence
                                      </div>
                                  </div>

                                  <div className="grid grid-cols-2 gap-4 text-xs mb-3">
                                      <div className="bg-black/30 p-2 rounded border border-zinc-800/50">
                                          <div className="text-zinc-500 font-bold uppercase mb-1">Intent</div>
                                          <div className="text-zinc-200">{cell.config.intent?.toUpperCase()}</div>
                                      </div>
                                      <div className="bg-black/30 p-2 rounded border border-zinc-800/50">
                                          <div className="text-zinc-500 font-bold uppercase mb-1">Goal</div>
                                          <div className="text-zinc-200">
                                              {cell.config.intent === 'distribution' ? 'Analyze Frequency' :
                                               cell.config.intent === 'relationship' ? 'Correlate Variables' :
                                               cell.config.intent === 'comparison' ? 'Compare Segments' : 'Identify Trends'}
                                          </div>
                                      </div>
                                  </div>

                                  <div className="space-y-2 border-t border-zinc-800/50 pt-2">
                                      <div className="flex items-center justify-between group">
                                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                                              <span className="w-16 font-bold text-zinc-500">X-Axis:</span>
                                              <span className="font-mono text-zinc-300">{cell.proposal.xAxis.column}</span>
                                              <span className="px-1.5 py-0.5 bg-zinc-800 rounded text-[10px] text-zinc-500">{cell.proposal.xAxis.role}</span>
                                          </div>
                                          {cell.status === 'waiting_confirmation' && (
                                               <button className="opacity-0 group-hover:opacity-100 text-[10px] text-violet-400 hover:underline">Change</button>
                                          )}
                                      </div>
                                      <div className="flex items-center justify-between group">
                                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                                              <span className="w-16 font-bold text-zinc-500">Y-Axis:</span>
                                              <span className="font-mono text-zinc-300">{cell.proposal.yAxis.column || 'N/A'}</span>
                                              <span className="px-1.5 py-0.5 bg-zinc-800 rounded text-[10px] text-zinc-500">{cell.proposal.yAxis.role}</span>
                                          </div>
                                          {cell.status === 'waiting_confirmation' && (
                                               <button className="opacity-0 group-hover:opacity-100 text-[10px] text-violet-400 hover:underline">Change</button>
                                          )}
                                      </div>
                                      <div className="flex items-center justify-between group">
                                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                                              <span className="w-16 font-bold text-zinc-500">Aggregation:</span>
                                              <span className={`font-mono font-bold ${cell.config.aggregation === 'sum' ? 'text-green-400' : 'text-blue-400'}`}>
                                                  {cell.config.aggregation?.toUpperCase()}
                                              </span>
                                          </div>
                                          {cell.status === 'waiting_confirmation' && (
                                               <div className="opacity-0 group-hover:opacity-100 flex gap-2">
                                                    <button onClick={() => handleCorrection(cell, 'aggregation', 'mean')} className="text-[10px] bg-zinc-800 px-1.5 rounded hover:text-white">Use Avg</button>
                                                    <button onClick={() => handleCorrection(cell, 'aggregation', 'count')} className="text-[10px] bg-zinc-800 px-1.5 rounded hover:text-white">Use Count</button>
                                               </div>
                                          )}
                                      </div>
                                      <div className="flex items-center justify-between group">
                                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                                              <span className="w-16 font-bold text-zinc-500">Chart:</span>
                                              <span className="font-mono text-zinc-300">{cell.config.chartType}</span>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          {cell.status === 'waiting_confirmation' && (
                              <div className="mt-4 flex justify-end gap-3 border-t border-zinc-800 pt-3">
                                  <div className="mr-auto text-[10px] text-zinc-500 italic flex items-center">
                                      <Info size={12} className="mr-1" />
                                      Review the AI assumptions above.
                                  </div>
                                  <button onClick={() => updateCell(cell.id, { status: 'draft' })} className="text-xs text-zinc-500 hover:text-white px-3 py-1.5">Reset</button>
                                  <button 
                                      onClick={() => executeCell(cell)}
                                      className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-1.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors"
                                  >
                                      <Play size={14} fill="currentColor" /> Approve & Run
                                  </button>
                              </div>
                          )}
                      </div>
                  )}

                  {cell.status === 'done' && cell.result && (
                      <div className="h-[400px] w-full animate-slide-up">
                          <ResponsiveContainer width="100%" height="100%">
                              {cell.config.chartType === 'histogram' ? (
                                   <BarChart data={cell.result}>
                                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                      <XAxis dataKey="name" stroke="#777" />
                                      <YAxis stroke="#777" label={{ value: 'Frequency', angle: -90, position: 'insideLeft' }} />
                                      <Tooltip contentStyle={{ backgroundColor: '#000', borderColor: '#333' }} />
                                      <Bar dataKey="value" fill="#8b5cf6" name="Count" />
                                  </BarChart>
                              ) : cell.config.chartType === 'bar' ? (
                                  <BarChart data={cell.result} layout={cell.type === 'city' || cell.type === 'products' ? 'vertical' : 'horizontal'}>
                                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                      {cell.type === 'city' || cell.type === 'products' ? (
                                          <>
                                              <XAxis type="number" stroke="#777" />
                                              <YAxis dataKey="name" type="category" stroke="#777" width={100} />
                                          </>
                                      ) : (
                                          <>
                                              <XAxis dataKey={cell.config.intent === 'trend' ? 'month' : 'name'} stroke="#777" />
                                              <YAxis stroke="#777" />
                                          </>
                                      )}
                                      <Tooltip contentStyle={{ backgroundColor: '#000', borderColor: '#333' }} />
                                      <Bar dataKey="value" fill="#8b5cf6" name={cell.config.aggregation?.toUpperCase()} />
                                  </BarChart>
                              ) : cell.config.chartType === 'line' ? (
                                  <LineChart data={cell.result}>
                                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                      <XAxis dataKey="hour" stroke="#777" />
                                      <YAxis stroke="#777" />
                                      <Tooltip contentStyle={{ backgroundColor: '#000', borderColor: '#333' }} />
                                      <Line type="monotone" dataKey="count" stroke="#f59e0b" strokeWidth={2} dot={{r:4}} />
                                  </LineChart>
                              ) : cell.config.chartType === 'scatter' ? (
                                  <ScatterChart>
                                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                      <XAxis type="number" dataKey="x" name={cell.config.xCol} stroke="#777" />
                                      <YAxis type="number" dataKey="y" name={cell.config.yCol} stroke="#777" />
                                      <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#000', borderColor: '#333' }} />
                                      <Scatter name="Correlation" data={cell.result} fill="#8884d8" />
                                  </ScatterChart>
                              ) : cell.type === 'outliers' && Array.isArray(cell.result) ? (
                                  <div className="h-full overflow-y-auto pr-2">
                                      {cell.result.map((res: any, idx: number) => (
                                          <div key={idx} className="mb-6">
                                              <div className="flex gap-4 mb-4">
                                                  <div className="bg-red-900/20 border border-red-900/50 rounded-lg p-4 flex-1">
                                                      <div className="text-xs text-red-400 font-bold uppercase mb-1">Outliers Detected</div>
                                                      <div className="text-2xl font-bold text-white">{res.count}</div>
                                                      <div className="text-xs text-zinc-500 mt-1">Method: {res.method}</div>
                                                  </div>
                                                  <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex-1">
                                                      <div className="text-xs text-zinc-500 font-bold uppercase mb-1">Lower Bound</div>
                                                      <div className="text-xl font-mono text-zinc-300">{res.boundary.min.toFixed(2)}</div>
                                                  </div>
                                                  <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 flex-1">
                                                      <div className="text-xs text-zinc-500 font-bold uppercase mb-1">Upper Bound</div>
                                                      <div className="text-xl font-mono text-zinc-300">{res.boundary.max.toFixed(2)}</div>
                                                  </div>
                                              </div>
                                              
                                              <div className="border border-zinc-800 rounded-lg overflow-hidden">
                                                  <table className="w-full text-sm text-left">
                                                      <thead className="bg-zinc-950 text-zinc-500 font-medium border-b border-zinc-800">
                                                          <tr>
                                                              <th className="px-4 py-2">ID</th>
                                                              <th className="px-4 py-2">Value</th>
                                                              <th className="px-4 py-2">Reason</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody className="divide-y divide-zinc-800">
                                                          {res.rows.map((row: any, rIdx: number) => (
                                                              <tr key={rIdx} className="hover:bg-zinc-900/50">
                                                                  <td className="px-4 py-2 font-mono text-zinc-400">{row.id}</td>
                                                                  <td className="px-4 py-2 font-mono text-red-400 font-bold">{row[res.column]}</td>
                                                                  <td className="px-4 py-2 text-zinc-500">{row.reason}</td>
                                                              </tr>
                                                          ))}
                                                      </tbody>
                                                  </table>
                                              </div>
                                          </div>
                                      ))}
                                  </div>
                              ) : (
                                  <div>Chart type not supported yet</div>
                              )}
                          </ResponsiveContainer>
                      </div>
                  )}

                  {cell.status === 'error' && (
                      <div className="p-4 bg-red-900/20 border border-red-900/50 rounded-lg text-red-400 text-sm flex items-center gap-2">
                          <AlertOctagon size={16} />
                          {cell.error}
                      </div>
                  )}
                  
                  {debugMode && (
                      <div className="mt-4 p-3 bg-black border border-zinc-800 rounded text-[10px] font-mono text-zinc-500 overflow-x-auto">
                          <div className="font-bold text-zinc-400 mb-1">DEBUG: Cell State</div>
                          {JSON.stringify(cell, null, 2)}
                      </div>
                  )}
              </div>
          </div>
      );
  };

  return (
    <div className="h-full flex flex-col">
      <div className="h-14 border-b border-zinc-800 flex items-center px-6 gap-4 bg-zinc-950/80 backdrop-blur sticky top-0 z-10">
          <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Add Analysis Block:</span>
          
          <button onClick={() => addCell('univariate', 'Univariate Distribution')} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 hover:border-violet-500 hover:text-violet-400 rounded-lg text-xs font-medium transition-all">
              <Activity size={14} /> Distribution
          </button>
          <button onClick={() => addCell('bivariate', 'Correlation Scatter')} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 hover:border-violet-500 hover:text-violet-400 rounded-lg text-xs font-medium transition-all">
              <Grid size={14} /> Correlation
          </button>
          <div className="h-4 w-px bg-zinc-800 mx-2"></div>
          <button onClick={() => addCell('monthly', 'Monthly Trends')} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 hover:border-violet-500 hover:text-violet-400 rounded-lg text-xs font-medium transition-all">
              <Calendar size={14} /> Monthly
          </button>
          <button onClick={() => addCell('hourly', 'Hourly Traffic')} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 hover:border-violet-500 hover:text-violet-400 rounded-lg text-xs font-medium transition-all">
              <Clock size={14} /> Hourly
          </button>
          <button onClick={() => addCell('outliers', 'Outlier Detection')} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 hover:border-red-500 hover:text-red-400 rounded-lg text-xs font-medium transition-all">
              <AlertOctagon size={14} /> Outliers
          </button>
          <div className="ml-auto flex items-center gap-3">
              <span className="text-xs text-zinc-600">Debug Mode</span>
              <button 
                  onClick={() => setDebugMode(!debugMode)} 
                  className={`w-8 h-4 rounded-full relative transition-colors ${debugMode ? 'bg-violet-600' : 'bg-zinc-800'}`}
              >
                  <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${debugMode ? 'translate-x-4' : ''}`} />
              </button>
          </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 scroll-smooth">
          <div className="max-w-4xl mx-auto">
              {cells.map(cell => renderCell(cell))}
              
              {cells.length > 0 && (
                  <div className="text-center p-8 border-2 border-dashed border-zinc-800 rounded-xl text-zinc-600">
                      <p className="mb-4">Add more analysis blocks from the toolbar above.</p>
                  </div>
              )}
          </div>
      </div>
    </div>
  );
};
