import React, { useState, useEffect } from 'react';
import { TableSchema, ValidationRun, ValidationRule, ValidationResult, ValidationLayer } from '../types';
import { ShieldCheck, Activity, AlertTriangle, ArrowRight, Play, CheckCircle, RotateCw, AlertOctagon, Info, Plus, ChevronDown, ChevronRight, X } from 'lucide-react';
import { mockRunValidationLayers, mockGetValidationRules } from '../services/mockApi';
import { useData } from '../services/dataContext';

interface ValidationViewProps {
  activeTable: TableSchema;
}

export const ValidationView: React.FC<ValidationViewProps> = ({ activeTable }) => {
  const { addToHistory } = useData();
  const [rules, setRules] = useState<ValidationRule[]>([]);
  const [lastRun, setValidationRun] = useState<ValidationRun | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [activeLayer, setActiveLayer] = useState<ValidationLayer | 'all'>('all');
  const [expandedRules, setExpandedRules] = useState<Set<string>>(new Set());
  const [showOverrideModal, setShowOverrideModal] = useState<string | null>(null); 
  const [overrideReason, setOverrideReason] = useState("");

  useEffect(() => {
    mockGetValidationRules(activeTable.tableName).then(setRules);
  }, [activeTable]);

  const handleRunValidation = async () => {
      setIsRunning(true);
      try {
          const result = await mockRunValidationLayers(activeTable.tableName, rules);
          setValidationRun(result);
          
          // Generate Summary and Log to History
          const failedCount = result.score.criticalFailures;
          const warningCount = result.score.warnings;
          const status = failedCount > 0 ? 'Failed' : warningCount > 0 ? 'Passed with Warnings' : 'Passed';
          
          let summary = `Validation Run completed. Status: ${status}. `;
          if (failedCount > 0) {
              const failedLayers = Object.entries(result.layerResults)
                  .filter(([_, res]) => res.some(r => r.status === 'fail'))
                  .map(([layer]) => layer);
              summary += `Critical failures found in layers: ${failedLayers.join(', ')}.`;
          } else {
              summary += `All ${rules.length} checks executed successfully.`;
          }

          addToHistory({
              user: 'Admin',
              action: 'validate',
              description: summary,
              versionId: 'v1.x'
          });

      } finally {
          setIsRunning(false);
      }
  };

  const toggleRuleExpand = (ruleId: string) => {
      const next = new Set(expandedRules);
      if (next.has(ruleId)) next.delete(ruleId);
      else next.add(ruleId);
      setExpandedRules(next);
  };

  const handleOverride = (ruleId: string) => {
      console.log(`Overriding rule ${ruleId}: ${overrideReason}`);
      setShowOverrideModal(null);
      setOverrideReason("");
      
      if (lastRun) {
          const updatedLayerResults = { ...lastRun.layerResults };
          Object.keys(updatedLayerResults).forEach(layer => {
              updatedLayerResults[layer as ValidationLayer] = updatedLayerResults[layer as ValidationLayer].map(res => 
                  res.ruleId === ruleId ? { ...res, status: 'warning' as const } : res
              );
          });
          setValidationRun({ ...lastRun, layerResults: updatedLayerResults });
      }
  };

  const getLayerStatus = (results: ValidationResult[]) => {
      if (results.some(r => r.status === 'fail')) return 'fail';
      if (results.some(r => r.status === 'warning')) return 'warning';
      return 'pass';
  };

  const renderResultBadge = (status: string) => {
      switch (status) {
          case 'pass': return <span className="bg-green-900/30 text-green-400 px-2 py-0.5 rounded text-xs font-bold border border-green-900/50">PASS</span>;
          case 'fail': return <span className="bg-red-900/30 text-red-400 px-2 py-0.5 rounded text-xs font-bold border border-red-900/50">FAIL</span>;
          case 'warning': return <span className="bg-yellow-900/30 text-yellow-400 px-2 py-0.5 rounded text-xs font-bold border border-yellow-900/50">WARNING</span>;
          default: return null;
      }
  };

  const renderLayerCell = (layer: ValidationLayer, title: string, description: string) => {
      if (!lastRun) return null;
      const results = lastRun.layerResults[layer];
      if (!results || results.length === 0) return null;

      const layerStatus = getLayerStatus(results);
      const isExpanded = activeLayer === 'all' || activeLayer === layer;

      return (
          <div className={`mb-6 border rounded-xl overflow-hidden transition-all ${
              layerStatus === 'fail' ? 'border-red-900/50 bg-red-950/5' : 
              layerStatus === 'warning' ? 'border-yellow-900/50 bg-yellow-950/5' : 
              'border-zinc-800 bg-zinc-900/20'
          }`}>
              <div className="px-6 py-4 border-b border-zinc-800/50 flex items-center justify-between bg-black/20">
                  <div className="flex items-center gap-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border ${
                          layerStatus === 'fail' ? 'bg-red-900/20 border-red-500 text-red-500' :
                          layerStatus === 'warning' ? 'bg-yellow-900/20 border-yellow-500 text-yellow-500' :
                          'bg-green-900/20 border-green-500 text-green-500'
                      }`}>
                          {layerStatus === 'fail' ? <AlertOctagon size={16} /> : 
                           layerStatus === 'warning' ? <AlertTriangle size={16} /> : 
                           <CheckCircle size={16} />}
                      </div>
                      <div>
                          <h3 className="text-lg font-bold text-zinc-200">{title}</h3>
                          <p className="text-xs text-zinc-500">{description}</p>
                      </div>
                  </div>
                  <div className="flex items-center gap-6">
                      <div className="flex gap-4 text-xs">
                          <span className="text-zinc-400"><strong className="text-white">{results.length}</strong> Rules</span>
                          <span className="text-red-400"><strong className="text-white">{results.filter(r => r.status === 'fail').length}</strong> Failures</span>
                      </div>
                  </div>
              </div>

              {isExpanded && (
                  <div className="divide-y divide-zinc-800/50">
                      {results.map(res => {
                          const rule = rules.find(r => r.id === res.ruleId);
                          if (!rule) return null;
                          const isRuleExpanded = expandedRules.has(res.ruleId);

                          return (
                              <div key={res.ruleId} className="p-4 hover:bg-zinc-900/30 transition-colors">
                                  <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleRuleExpand(res.ruleId)}>
                                      <div className="flex items-center gap-3">
                                          <div className="text-zinc-500">
                                              {isRuleExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                                          </div>
                                          <div className="flex flex-col">
                                              <span className="text-sm font-bold text-zinc-300">{rule.name}</span>
                                              <span className="text-xs font-mono text-zinc-600">{rule.expression}</span>
                                          </div>
                                      </div>
                                      <div className="flex items-center gap-4">
                                          {res.status !== 'pass' && (
                                              <span className="text-xs text-zinc-500">
                                                  {res.violationCount.toLocaleString()} violations ({res.violationPct.toFixed(1)}%)
                                              </span>
                                          )}
                                          {renderResultBadge(res.status)}
                                      </div>
                                  </div>

                                  {isRuleExpanded && res.status !== 'pass' && (
                                      <div className="mt-4 ml-8 bg-black/40 border border-zinc-800 rounded-lg p-4 animate-fade-in">
                                          <div className="flex justify-between items-start mb-3">
                                              <div>
                                                  <h4 className="text-xs font-bold text-red-400 uppercase mb-1">Failure Analysis</h4>
                                                  <p className="text-sm text-zinc-400">{rule.description}</p>
                                              </div>
                                              <button 
                                                  onClick={() => setShowOverrideModal(res.ruleId)}
                                                  className="text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 rounded border border-zinc-700 transition-colors"
                                              >
                                                  Override Rule
                                              </button>
                                          </div>

                                          <div className="space-y-2">
                                              <h5 className="text-[10px] font-bold text-zinc-500 uppercase">Sample Violations</h5>
                                              <div className="overflow-x-auto">
                                                  <table className="w-full text-left border-collapse">
                                                      <thead>
                                                          <tr className="border-b border-zinc-800 text-zinc-500 text-[10px] uppercase">
                                                              {res.sampleViolations.length > 0 && Object.keys(res.sampleViolations[0]).map(k => (
                                                                  <th key={k} className="px-2 py-1">{k}</th>
                                                              ))}
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                          {res.sampleViolations.map((v, idx) => (
                                                              <tr key={idx} className="text-xs text-zinc-300 border-b border-zinc-800/50 last:border-0">
                                                                  {Object.values(v).map((val: any, i) => (
                                                                      <td key={i} className="px-2 py-1 font-mono text-red-300">{String(val)}</td>
                                                                  ))}
                                                              </tr>
                                                          ))}
                                                      </tbody>
                                                  </table>
                                              </div>
                                          </div>
                                      </div>
                                  )}
                              </div>
                          );
                      })}
                  </div>
              )}
          </div>
      );
  };

  return (
    <div className="h-full flex flex-col bg-zinc-950 relative">
      <div className="border-b border-zinc-800 bg-zinc-900/50 p-6">
        <div className="flex justify-between items-center mb-6">
            <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="text-violet-500" /> Data Validation Dashboard
                </h2>
                <p className="text-zinc-400 text-sm mt-1">
                    Multi-layer integrity verification. Structural checks block analysis if failed.
                </p>
            </div>
            <button 
                onClick={handleRunValidation}
                disabled={isRunning}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-lg font-bold shadow-lg transition-all ${
                    isRunning ? 'bg-zinc-800 text-zinc-500 cursor-wait' : 'bg-violet-600 text-white hover:bg-violet-500 shadow-violet-900/20'
                }`}
            >
                {isRunning ? <RotateCw className="animate-spin" size={18} /> : <Play size={18} />} 
                {isRunning ? 'Running Suite...' : 'Run All Checks'}
            </button>
        </div>

        {lastRun ? (
            <div className="grid grid-cols-4 gap-4">
                <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg">
                    <div className="text-xs text-zinc-500 font-bold uppercase mb-1">Pass Rate</div>
                    <div className={`text-3xl font-bold ${lastRun.score.passRate === 100 ? 'text-green-400' : lastRun.score.passRate > 80 ? 'text-yellow-400' : 'text-red-400'}`}>
                        {lastRun.score.passRate.toFixed(1)}%
                    </div>
                </div>
                <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg">
                    <div className="text-xs text-zinc-500 font-bold uppercase mb-1">Critical Failures</div>
                    <div className={`text-3xl font-bold ${lastRun.score.criticalFailures === 0 ? 'text-zinc-200' : 'text-red-500'}`}>
                        {lastRun.score.criticalFailures}
                    </div>
                </div>
                <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg">
                    <div className="text-xs text-zinc-500 font-bold uppercase mb-1">Warnings</div>
                    <div className={`text-3xl font-bold ${lastRun.score.warnings === 0 ? 'text-zinc-200' : 'text-yellow-500'}`}>
                        {lastRun.score.warnings}
                    </div>
                </div>
                <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg flex items-center justify-center">
                    <div className={`text-center ${lastRun.score.criticalFailures > 0 ? 'text-red-400' : 'text-green-400'}`}>
                        <div className="text-xs font-bold uppercase mb-1">Status</div>
                        <div className="font-bold text-lg flex items-center gap-2 justify-center">
                            {lastRun.score.criticalFailures > 0 ? <AlertOctagon /> : <CheckCircle />}
                            {lastRun.score.criticalFailures > 0 ? 'UNSAFE' : 'HEALTHY'}
                        </div>
                    </div>
                </div>
            </div>
        ) : (
            <div className="p-8 border-2 border-dashed border-zinc-800 rounded-lg text-center text-zinc-500">
                Run validation to generate health report.
            </div>
        )}
      </div>

      <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 overflow-y-auto p-8">
              {lastRun ? (
                  <div className="max-w-4xl mx-auto">
                      {renderLayerCell('structural', 'Structural Integrity', 'Schema correctness, types, and primary keys. First gate.')}
                      
                      {lastRun.layerResults.structural.some(r => r.status === 'fail') ? (
                          <div className="p-6 bg-red-950/20 border border-red-900/50 rounded-xl text-center">
                              <AlertOctagon size={48} className="text-red-500 mx-auto mb-4" />
                              <h3 className="text-xl font-bold text-red-400 mb-2">Validation Blocked</h3>
                              <p className="text-zinc-400 max-w-lg mx-auto">
                                  Structural checks failed. Downstream analytical and logical checks cannot be trusted until schema issues are resolved.
                              </p>
                              <button className="mt-6 px-6 py-2 bg-red-900/50 hover:bg-red-900/80 text-red-200 rounded-lg font-bold transition-colors">
                                  Go to Clean Tab
                              </button>
                          </div>
                      ) : (
                          <>
                              {renderLayerCell('statistical', 'Statistical Sanity', 'Distribution shifts, outliers, and negative values.')}
                              {renderLayerCell('logical', 'Business Logic Rules', 'Domain-specific constraints (e.g. Price * Qty = Revenue).')}
                              {renderLayerCell('analytical', 'Metric Consistency', 'Reconciliation of aggregates across views.')}
                          </>
                      )}
                  </div>
              ) : (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-600">
                      <ShieldCheck size={64} className="mb-4 opacity-20" />
                      <p>Ready to validate {activeTable.tableName}</p>
                  </div>
              )}
          </div>

          <div className="w-80 border-l border-zinc-800 bg-zinc-950 flex flex-col">
              <div className="p-4 border-b border-zinc-800 flex justify-between items-center">
                  <h3 className="font-bold text-zinc-300">Active Rules</h3>
                  <button className="p-1 hover:bg-zinc-800 rounded text-zinc-500 hover:text-white"><Plus size={16}/></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {rules.map(rule => (
                      <div key={rule.id} className="p-3 bg-zinc-900 border border-zinc-800 rounded-lg group hover:border-zinc-600 transition-colors">
                          <div className="flex justify-between items-start mb-1">
                              <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                                  rule.severity === 'error' ? 'bg-red-900/30 text-red-400' : 'bg-yellow-900/30 text-yellow-400'
                              }`}>
                                  {rule.severity}
                              </span>
                              <span className="text-[10px] text-zinc-500 uppercase">{rule.layer}</span>
                          </div>
                          <div className="font-bold text-sm text-zinc-300 mb-1">{rule.name}</div>
                          <code className="text-[10px] font-mono text-zinc-500 bg-black px-1 rounded block truncate">
                              {rule.expression}
                          </code>
                      </div>
                  ))}
              </div>
          </div>
      </div>

      {showOverrideModal && (
          <div className="absolute inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
              <div className="bg-zinc-900 border border-zinc-700 rounded-xl p-6 w-full max-w-md shadow-2xl">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-bold text-white">Override Validation Rule</h3>
                      <button onClick={() => setShowOverrideModal(null)} className="text-zinc-500 hover:text-white"><X size={18}/></button>
                  </div>
                  <p className="text-sm text-zinc-400 mb-4">
                      You are about to suppress a validation failure. This action will be logged in the Assumption Registry.
                  </p>
                  <div className="mb-4">
                      <label className="text-xs font-bold text-zinc-500 uppercase mb-1 block">Reason for Override</label>
                      <textarea 
                          value={overrideReason}
                          onChange={(e) => setOverrideReason(e.target.value)}
                          placeholder="E.g., Legacy data migration issue, approved by Data Steward..."
                          className="w-full h-24 bg-black border border-zinc-700 rounded-lg p-3 text-sm text-white focus:border-violet-500 outline-none resize-none"
                      />
                  </div>
                  <div className="flex justify-end gap-3">
                      <button onClick={() => setShowOverrideModal(null)} className="px-4 py-2 text-sm text-zinc-400 hover:text-white">Cancel</button>
                      <button 
                          onClick={() => handleOverride(showOverrideModal)}
                          disabled={!overrideReason.trim()}
                          className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-sm font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                          Confirm Override
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
