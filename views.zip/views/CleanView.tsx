import React, { useEffect, useState, useRef } from 'react';
import { TableSchema, UserRole, AppMode, DataProfile, QualityIssue, CleaningCell, CleaningAction, DataQualityScorecard } from '../types';
import { mockGetProfiling, mockDetectIssues, mockApplyCleaningOp, mockGetQualityScorecard } from '../services/mockApi';
import { useData } from '../services/dataContext';
import { Sparkles, AlertTriangle, ArrowRight, Play, CheckCircle, X, ShieldCheck, Plus, Trash2, RotateCw, Activity, AlertOctagon, Info, ChevronRight, ChevronDown, Save, FileText, Database, Undo2 } from 'lucide-react';

interface CleanViewProps {
  activeTable: TableSchema;
  userRole: UserRole;
  appMode: AppMode;
  onUpdateTable?: (table: TableSchema) => void;
}

export const CleanView: React.FC<CleanViewProps> = ({ activeTable, userRole }) => {
  const { addToHistory } = useData();
  const [profilingData, setProfilingData] = useState<DataProfile[]>([]);
  const [issues, setIssues] = useState<QualityIssue[]>([]);
  const [scorecard, setScorecard] = useState<DataQualityScorecard | null>(null);
  const [cells, setCells] = useState<CleaningCell[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIssue, setSelectedIssue] = useState<QualityIssue | null>(null);
  const [showLog, setShowLog] = useState(false);
  
  useEffect(() => {
    const init = async () => {
        setLoading(true);
        try {
            const [profiles, detectedIssues, scores] = await Promise.all([
                mockGetProfiling(activeTable.tableName),
                mockDetectIssues(activeTable.tableName),
                mockGetQualityScorecard(activeTable.tableName)
            ]);
            setProfilingData(profiles);
            setIssues(detectedIssues);
            setScorecard(scores);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };
    init();
  }, [activeTable]);

  const handleSelectIssue = (issue: QualityIssue) => {
      setSelectedIssue(issue);
  };

  const handleProposeAction = (issue: QualityIssue, action: CleaningAction) => {
      const warning = Math.random() > 0.7 ? "\n\n⚠ WARNING: This change will invalidate 3 downstream analyses (Sales Forecast, Customer Churn)." : "";

      const newCell: CleaningCell = {
          id: `cell_${Date.now()}`,
          type: 'cleaning',
          issue: issue,
          action: action,
          status: 'planning',
          timestamp: new Date().toISOString(),
          logic_applied: `
Decision: ${action.label}
Target: ${issue.column}
Reason: ${issue.description}
Impact: ${action.impact_description}
${warning}
          `
      };
      setCells(prev => [...prev, newCell]);
      
      setTimeout(() => {
          document.getElementById('cells-end')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
  };

  const executeCell = async (cellId: string) => {
      setCells(prev => prev.map(c => c.id === cellId ? { ...c, status: 'executing' } : c));
      
      const cell = cells.find(c => c.id === cellId);
      if (!cell) return;

      try {
          await mockApplyCleaningOp(activeTable.tableName, cell.action);
          
          if (cell.issue) {
              setIssues(prev => prev.filter(i => i.id !== cell.issue!.id));
          }

          setCells(prev => prev.map(c => c.id === cellId ? { ...c, status: 'done' } : c));
          setSelectedIssue(null);

          addToHistory({
              user: 'Admin',
              action: 'clean',
              description: `Applied fix: ${cell.action?.label} on ${cell.issue?.column}`,
              versionId: `v${Date.now()}`,
              codeSnapshot: cell.logic_applied
          });

      } catch (e) {
          setCells(prev => prev.map(c => c.id === cellId ? { ...c, status: 'error' } : c));
      }
  };

  const revertCell = async (cellId: string) => {
      setCells(prev => prev.map(c => c.id === cellId ? { ...c, status: 'reverted' } : c));
  };

  const getSeverityColor = (s: string) => {
      switch(s) {
          case 'high': return 'text-red-400 bg-red-950/30 border-red-900/50';
          case 'medium': return 'text-yellow-400 bg-yellow-950/30 border-yellow-900/50';
          case 'low': return 'text-blue-400 bg-blue-950/30 border-blue-900/50';
          default: return 'text-zinc-400';
      }
  };

  if (loading) {
      return (
          <div className="h-full flex flex-col items-center justify-center space-y-4">
              <Activity className="w-12 h-12 text-violet-500 animate-pulse" />
              <div className="text-center">
                  <h3 className="text-lg font-bold text-white">Profiling Data...</h3>
                  <p className="text-zinc-500 text-sm">Scanning for quality issues, outliers, and schema mismatches.</p>
              </div>
          </div>
      );
  }

  return (
    <div className="h-full flex flex-col bg-zinc-950">
      <div className="flex-shrink-0 border-b border-zinc-800 bg-zinc-900/50 p-6">
          <div className="flex items-center justify-between mb-6">
              <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                      <ShieldCheck className="text-violet-400" /> Data Quality & Cleaning
                  </h2>
                  <p className="text-zinc-400 text-sm mt-1">
                      Professional Notebook-style cleaning. All actions are logged and reversible.
                  </p>
              </div>
              <div className="flex gap-2">
                   <button 
                      onClick={() => setShowLog(!showLog)}
                      className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-xs font-bold text-zinc-300 transition-colors border border-zinc-700"
                   >
                       <FileText size={14} /> Audit Log
                   </button>
                   <button className="flex items-center gap-2 px-3 py-2 bg-violet-600 hover:bg-violet-500 rounded-lg text-xs font-bold text-white transition-colors shadow-lg shadow-violet-900/20">
                       <Save size={14} /> Export Clean Data
                   </button>
              </div>
          </div>

          {scorecard && (
              <div className="grid grid-cols-4 gap-4">
                  <div className="bg-black/40 border border-zinc-800 p-3 rounded-lg">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Completeness</div>
                      <div className="text-2xl font-bold text-white">{scorecard.completeness}%</div>
                      <div className="w-full bg-zinc-800 h-1 mt-2 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500" style={{ width: `${scorecard.completeness}%` }}></div>
                      </div>
                  </div>
                  <div className="bg-black/40 border border-zinc-800 p-3 rounded-lg">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Validity</div>
                      <div className="text-2xl font-bold text-white">{scorecard.validity}%</div>
                      <div className="w-full bg-zinc-800 h-1 mt-2 rounded-full overflow-hidden">
                          <div className="h-full bg-green-500" style={{ width: `${scorecard.validity}%` }}></div>
                      </div>
                  </div>
                  <div className="bg-black/40 border border-zinc-800 p-3 rounded-lg">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Consistency</div>
                      <div className="text-2xl font-bold text-white">{scorecard.consistency}%</div>
                      <div className="w-full bg-zinc-800 h-1 mt-2 rounded-full overflow-hidden">
                          <div className="h-full bg-yellow-500" style={{ width: `${scorecard.consistency}%` }}></div>
                      </div>
                  </div>
                  <div className="bg-black/40 border border-zinc-800 p-3 rounded-lg">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Uniqueness</div>
                      <div className="text-2xl font-bold text-white">{scorecard.uniqueness}%</div>
                      <div className="w-full bg-zinc-800 h-1 mt-2 rounded-full overflow-hidden">
                          <div className="h-full bg-purple-500" style={{ width: `${scorecard.uniqueness}%` }}></div>
                      </div>
                  </div>
              </div>
          )}
      </div>

      <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 overflow-y-auto p-8 relative">
              {cells.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-500 opacity-50">
                      <Sparkles size={48} className="mb-4 text-zinc-700" />
                      <p>Select an issue from the right to begin cleaning.</p>
                  </div>
              ) : (
                  <div className="max-w-3xl mx-auto space-y-8">
                      {cells.map((cell, idx) => (
                          <div key={cell.id} className="relative group">
                              {idx < cells.length - 1 && (
                                  <div className="absolute left-6 top-full h-8 w-px bg-zinc-800 z-0"></div>
                              )}
                              
                              <div className={`relative z-10 bg-zinc-900 border rounded-xl overflow-hidden transition-all ${
                                  cell.status === 'executing' ? 'border-violet-500 shadow-lg shadow-violet-900/10' : 
                                  cell.status === 'done' ? 'border-zinc-800 opacity-80 hover:opacity-100' : 'border-zinc-700'
                              }`}>
                                  <div className="px-4 py-3 bg-black/20 border-b border-zinc-800/50 flex justify-between items-center">
                                      <div className="flex items-center gap-3">
                                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                              cell.status === 'done' ? 'bg-green-900/50 text-green-400' : 'bg-violet-900/50 text-violet-400'
                                          }`}>
                                              {idx + 1}
                                          </div>
                                          <span className="font-mono text-xs font-bold text-zinc-300">CLEANING_OP</span>
                                          <span className="text-xs text-zinc-500">{new Date(cell.timestamp).toLocaleTimeString()}</span>
                                      </div>
                                      <div className="flex items-center gap-2">
                                          {cell.status === 'done' && (
                                              <button onClick={() => revertCell(cell.id)} className="text-xs flex items-center gap-1 text-zinc-500 hover:text-red-400 px-2 py-1 rounded hover:bg-zinc-800 transition-colors">
                                                  <Undo2 size={12} /> Revert
                                              </button>
                                          )}
                                          <div className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                                              cell.status === 'done' ? 'bg-green-900/20 text-green-500' :
                                              cell.status === 'planning' ? 'bg-yellow-900/20 text-yellow-500' :
                                              'bg-blue-900/20 text-blue-500'
                                          }`}>
                                              {cell.status}
                                          </div>
                                      </div>
                                  </div>

                                  <div className="p-5">
                                      <div className="flex gap-6">
                                          <div className="flex-1 space-y-4">
                                              <div>
                                                  <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Issue Detected</div>
                                                  <div className="text-sm text-red-300 bg-red-950/20 border border-red-900/30 p-2 rounded flex items-center gap-2">
                                                      <AlertTriangle size={14} />
                                                      {cell.issue?.description}
                                                  </div>
                                              </div>
                                              <div>
                                                  <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Proposed Logic</div>
                                                  {cell.status === 'planning' ? (
                                                      <textarea
                                                          value={cell.logic_applied}
                                                          onChange={(e) => setCells(prev => prev.map(c => c.id === cell.id ? { ...c, logic_applied: e.target.value } : c))}
                                                          className="w-full min-h-[120px] bg-black border border-zinc-700 rounded p-3 text-xs font-mono text-zinc-300 focus:outline-none focus:border-violet-500 transition-colors resize-y whitespace-pre-wrap"
                                                      />
                                                  ) : (
                                                      <pre className="text-xs font-mono text-zinc-300 bg-black p-3 rounded border border-zinc-800 whitespace-pre-wrap">
                                                          {cell.logic_applied}
                                                      </pre>
                                                  )}
                                              </div>
                                          </div>
                                          
                                          {cell.status === 'planning' && (
                                              <div className="w-48 flex flex-col justify-center">
                                                  <div className="text-[10px] text-zinc-500 italic mb-2 text-center">
                                                      Review & edit logic before approving.
                                                  </div>
                                                  <button 
                                                      onClick={() => executeCell(cell.id)}
                                                      className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white font-bold rounded-lg text-sm flex items-center justify-center gap-2 shadow-lg shadow-violet-900/20 transition-all"
                                                  >
                                                      <Play size={14} fill="currentColor" /> Approve
                                                  </button>
                                                  <button 
                                                      onClick={() => setCells(prev => prev.filter(c => c.id !== cell.id))}
                                                      className="mt-2 w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white font-medium rounded-lg text-xs transition-all"
                                                  >
                                                      Cancel
                                                  </button>
                                              </div>
                                          )}
                                      </div>
                                  </div>
                              </div>
                          </div>
                      ))}
                      <div id="cells-end" className="h-10"></div>
                  </div>
              )}
          </div>

          <div className="w-96 border-l border-zinc-800 bg-zinc-950 flex flex-col">
              {showLog ? (
                  <div className="flex flex-col h-full">
                      <div className="p-4 border-b border-zinc-800 bg-zinc-900/50 flex items-center justify-between">
                          <h3 className="font-bold text-zinc-200 flex items-center gap-2">
                              <FileText size={16} className="text-zinc-400" /> Audit Log
                          </h3>
                          <button onClick={() => setShowLog(false)} className="text-zinc-500 hover:text-white"><X size={14}/></button>
                      </div>
                      <div className="flex-1 overflow-y-auto p-4 space-y-4">
                          <div className="text-xs text-zinc-500 mb-4">
                              Immutable record of all data transformations and assumptions.
                          </div>
                          {cells.filter(c => c.status === 'done').map((cell, i) => (
                              <div key={i} className="border-l-2 border-zinc-700 pl-4 py-1">
                                  <div className="text-[10px] text-zinc-500 font-mono mb-1">{new Date(cell.timestamp).toLocaleString()}</div>
                                  <div className="text-xs text-zinc-300 font-bold">{cell.action?.label}</div>
                                  <div className="text-xs text-zinc-500 italic">on {cell.issue?.column}</div>
                              </div>
                          ))}
                          {cells.filter(c => c.status === 'done').length === 0 && (
                              <div className="text-center text-zinc-600 text-xs italic mt-10">No actions recorded yet.</div>
                          )}
                      </div>
                  </div>
              ) : (
                  <>
                    <div className="p-4 border-b border-zinc-800 bg-zinc-900/50">
                        <h3 className="font-bold text-zinc-200 flex items-center gap-2">
                            <AlertOctagon size={16} className="text-yellow-500" />
                            Detected Issues ({issues.length})
                        </h3>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {issues.length === 0 ? (
                            <div className="text-center p-8 text-zinc-500 text-sm">
                                <CheckCircle size={32} className="mx-auto mb-2 text-green-500/50" />
                                No issues detected. Data is clean!
                            </div>
                        ) : (
                            issues.map(issue => (
                                <div 
                                    key={issue.id} 
                                    onClick={() => handleSelectIssue(issue)}
                                    className={`cursor-pointer rounded-lg border p-3 transition-all ${
                                        selectedIssue?.id === issue.id 
                                            ? 'bg-violet-900/10 border-violet-500 shadow-sm' 
                                            : 'bg-zinc-900 border-zinc-800 hover:border-zinc-600'
                                    }`}
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getSeverityColor(issue.severity)}`}>
                                            {issue.severity}
                                        </span>
                                        <span className="text-[10px] font-mono text-zinc-500">{issue.column}</span>
                                    </div>
                                    <h4 className="text-sm font-medium text-zinc-200 mb-1">{issue.category}</h4>
                                    <p className="text-xs text-zinc-400 line-clamp-2">{issue.description}</p>
                                    
                                    {selectedIssue?.id === issue.id && (
                                        <div className="mt-3 pt-3 border-t border-zinc-800/50 animate-fade-in">
                                            <div className="text-[10px] uppercase font-bold text-zinc-500 mb-2">Recommended Actions</div>
                                            <div className="space-y-2">
                                                {issue.suggested_actions.map(action => (
                                                    <button 
                                                        key={action.id}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleProposeAction(issue, action);
                                                        }}
                                                        className="w-full text-left p-2 rounded bg-black border border-zinc-800 hover:border-violet-500 hover:bg-violet-900/10 group transition-all"
                                                    >
                                                        <div className="flex items-center justify-between">
                                                            <span className="text-xs font-bold text-zinc-300 group-hover:text-violet-300">{action.label}</span>
                                                            <ArrowRight size={12} className="opacity-0 group-hover:opacity-100 text-violet-500" />
                                                        </div>
                                                        <div className="text-[10px] text-zinc-500 mt-0.5">{action.impact_description}</div>
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            ))
                        )}
                    </div>
                  </>
              )}
          </div>
      </div>
    </div>
  );
};
