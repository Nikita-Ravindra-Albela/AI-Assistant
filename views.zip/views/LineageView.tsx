import React, { useState } from 'react';
import { useData } from '../services/dataContext';
import { GitCommit, Clock, User, FileText, Download, Shield, Activity, Search, FileJson, CheckCircle, Brain, Database, TrendingUp } from 'lucide-react';
import { TraeRecord } from '../types';

export const LineageView: React.FC = () => {
  const { traeRecords, cells, dataState } = useData();

  const ingestCell = cells.find(c => c.type === 'ingest' && c.output);
  const understanding = ingestCell?.aiUnderstanding;
  const dataset = dataState.datasets[dataState.activeDatasetId || ''];

  const actions = {
      clean: traeRecords.filter(r => r.user_prompt.toLowerCase().includes('clean')).length,
      validate: traeRecords.filter(r => r.user_prompt.toLowerCase().includes('validate')).length,
      eda: traeRecords.filter(r => r.user_prompt.toLowerCase().includes('analyze') || r.user_prompt.toLowerCase().includes('plot')).length
  };

  const edaFindings = [
      "Missing values pattern detected in 'customer_email'",
      "High cardinality warning for 'city_name'",
      "3 duplicate transactions identified"
  ]; // Mock findings derived from logs

  const handleDownload = (format: 'md' | 'json') => {
      let content = '';
      let filename = `trae_audit_log_${Date.now()}`;

      if (format === 'json') {
          content = JSON.stringify(traeRecords, null, 2);
          filename += '.json';
      } else {
          content = `# TRAE Audit Log - DataWise Local AI
Generated: ${new Date().toLocaleString()}

${traeRecords.map((r, i) => `
## Step ${i + 1}: ${r.user_prompt}
**Timestamp:** ${new Date(r.timestamp).toISOString()}
**Session ID:** ${r.session_id} | **Cell ID:** ${r.cell_id}

### AI Rationale
> ${r.ai_rationale}

### Execution Plan
${r.proposed_steps.map(s => `- [Step ${s.step_id}] **${s.type.toUpperCase()}**: ${s.description}`).join('\n')}

### Validation Results
- Steps Validated: ${r.validation_results?.steps_validated || 0}
- Warnings: ${r.validation_results?.warnings?.length || 0}

**Approved By User:** ${r.approved_by_user ? 'YES' : 'NO'}
-------------------
`).join('\n')}
          `;
          filename += '.md';
      }

      const blob = new Blob([content], { type: format === 'json' ? 'application/json' : 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
  };

  const getIcon = (prompt: string) => {
      if (prompt.includes('clean')) return <Shield size={16} className="text-blue-400" />;
      if (prompt.includes('validate')) return <Activity size={16} className="text-green-400" />;
      return <GitCommit size={16} className="text-zinc-400" />;
  };

  return (
    <div className="h-full flex flex-col bg-zinc-950">
      <div className="border-b border-zinc-800 bg-zinc-900/50 p-6 flex justify-between items-center">
        <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <GitCommit className="text-violet-500" /> TRAE Audit Log
            </h2>
            <p className="text-zinc-400 text-sm mt-1">
                Compliance-grade record of all AI suggestions, user approvals, and executions.
            </p>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={() => handleDownload('json')}
                className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs font-bold border border-zinc-700 transition-colors"
            >
                <FileJson size={14} /> JSON Export
            </button>
            <button 
                onClick={() => handleDownload('md')}
                className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs font-bold border border-zinc-700 transition-colors"
            >
                <FileText size={14} /> Markdown Report
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-4xl mx-auto">
              {/* Executive Summary Section */}
              {ingestCell && (
                  <div className="mb-12 bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 rounded-xl overflow-hidden shadow-2xl">
                      <div className="bg-zinc-900/50 px-6 py-4 border-b border-zinc-800 flex justify-between items-center">
                          <h3 className="text-lg font-bold text-white flex items-center gap-2">
                              <Brain className="text-violet-500" /> Executive Summary
                          </h3>
                          <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 bg-black/50 px-3 py-1 rounded-full border border-zinc-800">
                              AI Generated
                          </span>
                      </div>
                      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                          {/* 1. Data Understanding */}
                          <div>
                              <div className="text-xs font-bold text-zinc-500 uppercase mb-3 flex items-center gap-2">
                                  <Database size={14} /> Data Understanding
                              </div>
                              <div className="text-sm text-zinc-300 leading-relaxed space-y-3">
                                  <p>
                                      The system has identified this as <strong className="text-white">{understanding?.domainGuess || 'Unknown'}</strong> data. 
                                      It contains <strong className="text-white">{dataset?.rowCount?.toLocaleString() || 0} records</strong> and <strong className="text-white">{dataset?.columns.length || 0} columns</strong>.
                                  </p>
                                  <div className="flex flex-wrap gap-2">
                                      {understanding?.keyIdentifiers?.map(id => (
                                          <span key={id} className="px-2 py-1 bg-zinc-800 text-zinc-400 text-xs rounded border border-zinc-700">
                                              ID: {id}
                                          </span>
                                      ))}
                                      {understanding?.targetVariable && (
                                          <span className="px-2 py-1 bg-violet-900/20 text-violet-400 text-xs rounded border border-violet-900/50">
                                              Target: {understanding.targetVariable}
                                          </span>
                                      )}
                                  </div>
                              </div>
                          </div>

                          {/* 2. Actions & Results */}
                          <div>
                              <div className="text-xs font-bold text-zinc-500 uppercase mb-3 flex items-center gap-2">
                                  <Activity size={14} /> Workflow Impact
                              </div>
                              <div className="grid grid-cols-3 gap-3 mb-4">
                                  <div className="bg-zinc-900/50 p-2 rounded border border-zinc-800 text-center">
                                      <div className="text-lg font-bold text-blue-400">{actions.clean}</div>
                                      <div className="text-[10px] text-zinc-500 uppercase">Cleaning</div>
                                  </div>
                                  <div className="bg-zinc-900/50 p-2 rounded border border-zinc-800 text-center">
                                      <div className="text-lg font-bold text-green-400">{actions.validate}</div>
                                      <div className="text-[10px] text-zinc-500 uppercase">Checks</div>
                                  </div>
                                  <div className="bg-zinc-900/50 p-2 rounded border border-zinc-800 text-center">
                                      <div className="text-lg font-bold text-yellow-400">{actions.eda}</div>
                                      <div className="text-[10px] text-zinc-500 uppercase">Insights</div>
                                  </div>
                              </div>
                              {edaFindings.length > 0 && (
                                  <div className="space-y-2">
                                      {edaFindings.map((finding, i) => (
                                          <div key={i} className="flex items-start gap-2 text-xs text-zinc-400">
                                              <TrendingUp size={14} className="text-zinc-600 mt-0.5 shrink-0" />
                                              <span>{finding}</span>
                                          </div>
                                      ))}
                                  </div>
                              )}
                          </div>
                      </div>
                  </div>
              )}

              <div className="relative">
                  <div className="absolute left-6 top-0 bottom-0 w-px bg-zinc-800"></div>

              {traeRecords.length === 0 && (
                  <div className="text-center text-zinc-500 py-10 pl-10">
                      No actions recorded yet. Run a cell in the Notebook to generate audit logs.
                  </div>
              )}

              {traeRecords.map((record, idx) => (
                  <div key={record.cell_id + idx} className="relative pl-16 pb-8 group">
                      <div className="absolute left-3 -translate-x-1/2 top-0 w-6 h-6 rounded-full bg-zinc-900 border-2 border-zinc-700 flex items-center justify-center group-hover:border-violet-500 transition-all z-10">
                          {getIcon(record.user_prompt)}
                      </div>

                      <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5 hover:border-zinc-700 transition-colors">
                          <div className="flex justify-between items-start mb-3">
                              <div className="flex items-center gap-2">
                                  <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[10px] font-bold uppercase tracking-wider">
                                      ACTION {idx + 1}
                                  </span>
                                  <span className="text-xs text-zinc-500 font-mono">{record.cell_id.split('_')[1]}</span>
                              </div>
                              <div className="flex items-center gap-4 text-xs text-zinc-500">
                                  <span className="flex items-center gap-1"><User size={12}/> User</span>
                                  <span className="flex items-center gap-1"><Clock size={12}/> {new Date(record.timestamp).toLocaleTimeString()}</span>
                              </div>
                          </div>
                          
                          <h3 className="text-sm font-bold text-zinc-200 mb-2">"{record.user_prompt}"</h3>
                          
                          <div className="grid grid-cols-2 gap-4 mt-4">
                              <div className="bg-black/30 p-3 rounded border border-zinc-800/50">
                                  <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">AI Rationale</div>
                                  <p className="text-xs text-zinc-400 italic leading-relaxed">{record.ai_rationale}</p>
                              </div>
                              <div className="bg-black/30 p-3 rounded border border-zinc-800/50">
                                  <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Validation Status</div>
                                  <div className="flex items-center gap-2 text-xs text-green-400 font-bold">
                                      <CheckCircle size={12} />
                                      Verified {record.validation_results?.steps_validated} steps
                                  </div>
                              </div>
                          </div>

                          <div className="mt-4">
                              <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Executed Steps</div>
                              <div className="space-y-1">
                                  {record.proposed_steps.map((step, i) => (
                                      <div key={i} className="text-xs text-zinc-300 font-mono flex items-center gap-2">
                                          <span className="text-violet-500">➜</span>
                                          {step.description}
                                      </div>
                                  ))}
                              </div>
                          </div>
                      </div>
                  </div>
              ))}
              </div>
          </div>
      </div>
    </div>
  );
};
