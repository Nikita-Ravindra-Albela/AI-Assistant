import React, { useState, useEffect } from 'react';
import { TableSchema, QueryResult } from '../types';
import { Play, Database, Clock, Download, ChevronRight, RotateCw, Terminal } from 'lucide-react';
import { mockRunSql } from '../services/mockApi';

interface SqlEditorViewProps {
  activeTable: TableSchema;
}

export const SqlEditorView: React.FC<SqlEditorViewProps> = ({ activeTable }) => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<QueryResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<string[]>([]);

  useEffect(() => {
    setQuery(`SELECT * FROM ${activeTable.tableName} LIMIT 100;`);
  }, [activeTable]);

  const handleRunQuery = async () => {
    if (!query.trim()) return;
    
    setLoading(true);
    try {
      // Simulate API call
      const res = await mockRunSql(query);
      setResult(res);
      setHistory(prev => [query, ...prev].slice(0, 10));
    } catch (error) {
      console.error("Query failed", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-zinc-950">
      {/* 1. Top Bar */}
      <div className="h-14 border-b border-zinc-800 bg-zinc-900/50 flex items-center px-4 justify-between">
        <div className="flex items-center gap-2 text-zinc-400">
          <Terminal size={16} />
          <span className="font-bold text-zinc-200">SQL Editor</span>
          <ChevronRight size={14} />
          <span className="font-mono text-xs bg-zinc-800 px-2 py-0.5 rounded text-zinc-300">{activeTable.tableName}</span>
        </div>
        <div className="flex items-center gap-2">
           <button className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold text-zinc-300 transition-colors">
               <Clock size={14} /> History
           </button>
           <button className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold text-zinc-300 transition-colors">
               <Download size={14} /> Export CSV
           </button>
        </div>
      </div>

      {/* 2. Editor Area */}
      <div className="h-48 border-b border-zinc-800 bg-black relative flex flex-col">
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="flex-1 bg-transparent text-zinc-300 font-mono text-sm p-4 focus:outline-none resize-none"
          placeholder="Enter your SQL query here..."
          spellCheck={false}
        />
        <div className="absolute bottom-4 right-4">
          <button 
            onClick={handleRunQuery}
            disabled={loading}
            className={`flex items-center gap-2 px-6 py-2 rounded-lg font-bold shadow-lg transition-all ${
                loading ? 'bg-zinc-800 text-zinc-500 cursor-wait' : 'bg-violet-600 text-white hover:bg-violet-500 shadow-violet-900/20'
            }`}
          >
            {loading ? <RotateCw className="animate-spin" size={16} /> : <Play size={16} fill="currentColor" />}
            {loading ? 'Running...' : 'Run Query'}
          </button>
        </div>
      </div>

      {/* 3. Results Area */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {result ? (
          <>
            <div className="px-4 py-2 bg-zinc-900/50 border-b border-zinc-800 flex justify-between items-center">
               <div className="flex items-center gap-4 text-xs">
                 <span className="text-zinc-500">Rows: <strong className="text-zinc-300">{result.rows.length}</strong></span>
                 <span className="text-zinc-500">Cols: <strong className="text-zinc-300">{result.columns.length}</strong></span>
                 <span className="text-zinc-500 flex items-center gap-1">
                    <Clock size={12} /> {result.executionTimeMs}ms
                 </span>
               </div>
               <div className="text-[10px] text-green-500 font-bold uppercase tracking-wider">Query Successful</div>
            </div>
            
            <div className="flex-1 overflow-auto">
              <table className="w-full text-left border-collapse">
                <thead className="sticky top-0 bg-zinc-900 z-10 shadow-sm">
                  <tr>
                    {result.columns.map((col, idx) => (
                      <th key={idx} className="px-4 py-3 text-xs font-bold text-zinc-400 border-b border-zinc-800 uppercase tracking-wider whitespace-nowrap">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {result.rows.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-zinc-900/30 transition-colors group">
                      {result.columns.map((col, cIdx) => (
                        <td key={cIdx} className="px-4 py-2 text-sm text-zinc-300 border-r border-zinc-800/30 last:border-0 font-mono whitespace-nowrap overflow-hidden text-ellipsis max-w-[200px]">
                           {row[col] !== null ? String(row[col]) : <span className="text-zinc-600 italic">null</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-zinc-600 space-y-4">
             <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center border border-zinc-800">
                <Database size={32} className="opacity-50" />
             </div>
             <p className="text-sm">Run a query to view results</p>
          </div>
        )}
      </div>
    </div>
  );
};
