import React, { useState, useEffect } from 'react';
import { AlertOctagon, ChevronDown, ChevronRight, Download, Wrench, Ban, CheckCircle, Table as TableIcon, AlertTriangle, ShieldCheck, Clock, Activity, Brain, X, Play, Code } from 'lucide-react';
import { QualityIssue, IssueCategory } from '../types';

interface EvidenceTableProps {
  type: string;
  data: any[];
  columns: { key: string; label: string; width?: string }[];
  onExclude: () => void;
  onAccept: () => void;
  onApplyFix: () => void;
}

const EvidenceTable: React.FC<EvidenceTableProps> = ({ type, data, columns, onExclude, onAccept, onApplyFix }) => {
  const [viewLimit, setViewLimit] = useState<number | 'all'>(5);

  const handleDownload = () => {
    if (!data || data.length === 0) return;

    const headers = columns.map(col => col.label).join(',');
    const rows = data.map(row => 
      columns.map(col => {
        const val = row[col.key];
        return val === null ? 'NULL' : `"${val}"`;
      }).join(',')
    );

    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${type}_evidence_export.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const displayedData = viewLimit === 'all' ? data : data.slice(0, viewLimit);

  return (
    <div className="mt-4 border-t border-zinc-800/50 pt-4 animate-in slide-in-from-top-2">
      <div className="flex items-center justify-between mb-2 px-1">
        <div className="text-[10px] uppercase font-bold text-zinc-500 flex items-center gap-2">
          <TableIcon size={12} /> Evidence Table
        </div>
        <div className="flex gap-2">
          <div className="relative group">
             <select 
                className="bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-300 rounded px-2 py-1 outline-none focus:border-violet-500 cursor-pointer appearance-none pr-6"
                value={viewLimit}
                onChange={(e) => setViewLimit(e.target.value === 'all' ? 'all' : Number(e.target.value))}
             >
                <option value={5}>Preview (5 rows)</option>
                <option value={10}>Preview (10 rows)</option>
                <option value="all">View All ({data.length} rows)</option>
             </select>
             <ChevronDown size={10} className="absolute right-2 top-1.5 text-zinc-500 pointer-events-none" />
          </div>

          <button 
            onClick={handleDownload}
            className="text-[10px] flex items-center gap-1 text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 px-2 py-1 rounded transition-colors"
          >
            <Download size={10} /> Download CSV
          </button>
        </div>
      </div>
      
      <div className="overflow-x-auto border border-zinc-800 rounded-lg bg-black/20 max-h-60 overflow-y-auto">
        <table className="w-full text-xs text-left">
          <thead className="bg-black text-[10px] uppercase text-zinc-500 font-bold sticky top-0 z-10">
            <tr>
              {columns.map(col => (
                <th key={col.key} className="px-3 py-2 border-b border-zinc-800 bg-black" style={{ width: col.width }}>
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/50">
            {displayedData.map((row, idx) => (
              <tr key={idx} className="hover:bg-zinc-800/30 transition-colors">
                {columns.map(col => (
                  <td key={col.key} className="px-3 py-2 text-zinc-300 font-mono">
                    {row[col.key] === null || row[col.key] === undefined ? (
                      <span className="text-red-500 italic">NULL</span>
                    ) : (
                      row[col.key]
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {viewLimit !== 'all' && data.length > viewLimit && (
          <div className="text-[10px] text-zinc-500 text-center mt-2 italic">
              Showing first {viewLimit} of {data.length} rows. Select "View All" to see entire dataset.
          </div>
      )}

      <div className="flex gap-2 mt-3 justify-end">
        <button 
            onClick={onExclude}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[10px] font-bold border border-zinc-700 transition-colors"
        >
            <Ban size={12} /> Exclude Rows
        </button>
        <button 
            onClick={onAccept}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[10px] font-bold border border-zinc-700 transition-colors"
        >
            <CheckCircle size={12} /> Mark as Accepted
        </button>
        <button 
            onClick={onApplyFix}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded text-[10px] font-bold shadow-lg shadow-violet-900/20 transition-colors"
        >
            <Wrench size={12} /> Apply Fix
        </button>
      </div>
    </div>
  );
};

export const QualityDiagnosticSummary: React.FC = () => {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [issues, setIssues] = useState<QualityIssue[]>([]);
  const [fixModalOpen, setFixModalOpen] = useState(false);
  const [selectedIssueForFix, setSelectedIssueForFix] = useState<QualityIssue | null>(null);

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  // ----------------------------------------------------------------------
  // MOCK DATA GENERATION
  // ----------------------------------------------------------------------

  const generateMockIssues = (): QualityIssue[] => {
      const issues: QualityIssue[] = [];

      // 1. Schema Issue: Column Type Mismatch
      issues.push({
          id: 'schema_1',
          category: 'Schema Issue',
          subcategory: 'Column Type Mismatch',
          severity: 'high',
          column: 'purchase_amount',
          description: "Numeric values stored as strings (e.g., '1,000').",
          affected_rows: 150,
          affected_pct: 12.5,
          confidence: 0.95,
          fixability: 'auto',
          risk: 'Low risk. Standard casting.',
          suggested_actions: [],
          evidence_columns: [{ key: 'row_id', label: 'Row ID' }, { key: 'raw_value', label: 'Raw Value' }, { key: 'inferred_type', label: 'Inferred Type' }],
          evidence_data: Array.from({ length: 15 }, (_, i) => ({ row_id: i + 1, raw_value: `"${1000 + i * 50}"`, inferred_type: 'String' }))
      });

      // 2. Missing Data: Systematic Missing
      issues.push({
          id: 'missing_1',
          category: 'Missing Data',
          subcategory: 'Systematic Missing Pattern',
          severity: 'medium',
          column: 'discount_code',
          description: "Missing only for 'Premium' customers. Likely systematic.",
          affected_rows: 450,
          affected_pct: 35,
          confidence: 0.88,
          fixability: 'review',
          risk: 'Imputation may bias analysis if not handled by segment.',
          suggested_actions: [],
          evidence_columns: [{ key: 'row_id', label: 'Row ID' }, { key: 'customer_tier', label: 'Customer Tier' }, { key: 'discount_code', label: 'Discount Code' }],
          evidence_data: Array.from({ length: 10 }, (_, i) => ({ row_id: i + 100, customer_tier: 'Premium', discount_code: null }))
      });

      // 3. Duplicate Data: Fuzzy Duplicates
      issues.push({
          id: 'dup_1',
          category: 'Duplicate Data',
          subcategory: 'Near-Duplicate (Fuzzy)',
          severity: 'medium',
          column: 'customer_email',
          description: "Potential typos detected (e.g. 'john@gmail.com' vs 'j0hn@gmail.com').",
          affected_rows: 12,
          affected_pct: 1.2,
          confidence: 0.75,
          fixability: 'review',
          risk: 'High risk of merging distinct users. Manual review recommended.',
          suggested_actions: [],
          evidence_columns: [{ key: 'group_id', label: 'Group' }, { key: 'email_variant_1', label: 'Variant A' }, { key: 'email_variant_2', label: 'Variant B' }, { key: 'similarity', label: 'Similarity Score' }],
          evidence_data: [
              { group_id: 1, email_variant_1: 'sarah.j@test.com', email_variant_2: 'sara.j@test.com', similarity: '92%' },
              { group_id: 2, email_variant_1: 'mike_smith@corp.org', email_variant_2: 'mike.smith@corp.org', similarity: '95%' }
          ]
      });

      // 4. Value Quality: Outliers
      issues.push({
          id: 'val_1',
          category: 'Value Quality',
          subcategory: 'Statistical Outliers',
          severity: 'low',
          column: 'order_total',
          description: "Values exceed 3 standard deviations from mean.",
          affected_rows: 5,
          affected_pct: 0.4,
          confidence: 0.99,
          fixability: 'review',
          risk: 'May be valid high-value transactions.',
          suggested_actions: [],
          evidence_columns: [{ key: 'row_id', label: 'Row ID' }, { key: 'order_total', label: 'Value' }, { key: 'z_score', label: 'Z-Score' }],
          evidence_data: [
              { row_id: 55, order_total: 50000, z_score: 4.2 },
              { row_id: 89, order_total: 120000, z_score: 8.5 }
          ]
      });

       // 5. Categorical Issue: High Cardinality
       issues.push({
          id: 'cat_1',
          category: 'Categorical Issue',
          subcategory: 'High Cardinality Explosion',
          severity: 'medium',
          column: 'city_name',
          description: "Column has 10,000 unique values. May contain spelling variants.",
          affected_rows: 10000,
          affected_pct: 100,
          confidence: 0.85,
          fixability: 'review',
          risk: 'Grouping may lose granularity.',
          suggested_actions: [],
          evidence_columns: [{ key: 'value', label: 'Value' }, { key: 'count', label: 'Count' }],
          evidence_data: [
              { value: 'New York', count: 1500 },
              { value: 'New York City', count: 200 },
              { value: 'NY', count: 50 },
              { value: 'NYC', count: 25 }
          ]
      });

      // 6. Temporal Issue: Future Dates
      issues.push({
          id: 'time_1',
          category: 'Temporal Issue',
          subcategory: 'Invalid Dates (Future)',
          severity: 'high',
          column: 'signup_date',
          description: "Dates are in the future (relative to today).",
          affected_rows: 3,
          affected_pct: 0.1,
          confidence: 1.0,
          fixability: 'auto',
          risk: 'None. Impossible data.',
          suggested_actions: [],
          evidence_columns: [{ key: 'row_id', label: 'Row ID' }, { key: 'signup_date', label: 'Date Value' }],
          evidence_data: [
              { row_id: 991, signup_date: '2050-01-01' },
              { row_id: 992, signup_date: '2028-12-12' }
          ]
      });

      return issues;
  };

  useEffect(() => {
    setIssues(generateMockIssues());
  }, []);

  // Action Handlers
  const handleExcludeRows = (issueId: string) => {
      setIssues(prev => prev.map(issue => {
          if (issue.id !== issueId) return issue;
          // Simulate removing rows by clearing evidence and count
          return {
              ...issue,
              affected_rows: 0,
              affected_pct: 0,
              evidence_data: [],
              description: `${issue.description} (Rows Excluded)`
          };
      }).filter(issue => issue.affected_rows > 0 || issue.id === issueId)); // Keep showing but empty, or remove? Requirements said "exclude rows from uploaded data". Since we are mocking, let's just update state to reflect "done".
      
      // Better UX: actually remove the issue from the list if resolved? Or mark as resolved?
      // Requirement: "exclude rows should remove the rows from the uploaded data."
      // Let's remove the issue from the UI to signify it's handled.
      setIssues(prev => prev.filter(i => i.id !== issueId));
  };

  const handleAcceptIssue = (issueId: string) => {
      // "Mark as accepted should ignore the evidence and accept the Evidence table as it is"
      // This implies treating it as NOT an issue anymore.
      setIssues(prev => prev.filter(i => i.id !== issueId));
  };

  const handleApplyFix = (issue: QualityIssue) => {
      setSelectedIssueForFix(issue);
      setFixModalOpen(true);
  };

  const applyFixCode = () => {
      if (selectedIssueForFix) {
          // In a real app, this would execute the code against the backend
          setIssues(prev => prev.filter(i => i.id !== selectedIssueForFix.id));
          setFixModalOpen(false);
          setSelectedIssueForFix(null);
      }
  };

  const generatePythonCode = (issue: QualityIssue) => {
      switch (issue.category) {
          case 'Schema Issue':
              return `
# Convert '${issue.column}' to numeric, coercing errors to NaN
df['${issue.column}'] = pd.to_numeric(df['${issue.column}'], errors='coerce')

# Check conversion success rate
print(f"Conversion complete. NaNs: {df['${issue.column}'].isna().sum()}")
              `;
          case 'Missing Data':
              return `
# Impute missing values in '${issue.column}'
# Strategy: Fill with 'Unknown' or Mode depending on business logic
mode_val = df['${issue.column}'].mode()[0]
df['${issue.column}'].fillna(mode_val, inplace=True)
              `;
          case 'Duplicate Data':
              return `
# Drop duplicates based on fuzzy match grouping
# Keeping the first occurrence
df = df.drop_duplicates(subset=['${issue.column}'], keep='first')
              `;
          case 'Value Quality':
              return `
# Remove outliers in '${issue.column}' using Z-score
from scipy import stats
z_scores = stats.zscore(df['${issue.column}'])
df = df[(z_scores < 3)]
              `;
          case 'Categorical Issue':
              return `
# Standardize categorical values in '${issue.column}'
# Example: Lowercase and strip whitespace
df['${issue.column}'] = df['${issue.column}'].str.lower().str.strip()
              `;
          case 'Temporal Issue':
              return `
# Remove rows with future dates in '${issue.column}'
import pandas as pd
now = pd.Timestamp.now()
df = df[pd.to_datetime(df['${issue.column}']) <= now]
              `;
          default:
              return `# Generic fix for ${issue.category}\n# Review data before applying.`;
      }
  };

  // Helper to map category to color theme
  const getTheme = (severity: string) => {
      switch(severity) {
          case 'high': return { bg: 'bg-red-950/10', border: 'border-red-900/50', text: 'text-red-200', sub: 'text-red-300/70', icon: 'bg-red-500' };
          case 'medium': return { bg: 'bg-yellow-950/10', border: 'border-yellow-900/50', text: 'text-yellow-200', sub: 'text-yellow-300/70', icon: 'bg-yellow-500' };
          default: return { bg: 'bg-blue-950/10', border: 'border-blue-900/50', text: 'text-blue-200', sub: 'text-blue-300/70', icon: 'bg-blue-500' };
      }
  };

  return (
    <div className="mb-6 group animate-fade-in ml-11 relative">
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden shadow-xl">
        <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
          <span className="text-xs font-bold text-violet-400 flex items-center gap-2">
            <Brain size={14} /> AI Quality Diagnostics
          </span>
          <span className="text-[10px] text-zinc-600 font-mono">ID: DIAG_FULL_001</span>
        </div>
        
        <div className="p-4 space-y-3">
          {issues.length === 0 ? (
             <div className="text-center py-8 text-zinc-500 text-sm italic">
                 All quality issues resolved.
             </div>
          ) : issues.map((issue) => {
              const theme = getTheme(issue.severity);
              const isExpanded = expandedSection === issue.id;

              return (
                  <div key={issue.id} className={`p-3 border rounded-lg transition-all ${
                      isExpanded ? theme.bg + ' ' + theme.border : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'
                  }`}>
                    <div className="flex items-start gap-3 cursor-pointer" onClick={() => toggleSection(issue.id)}>
                      <div className={`w-1.5 h-1.5 rounded-full ${theme.icon} mt-1.5 flex-shrink-0`}></div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <span className={`text-xs font-bold ${theme.text}`}>{issue.category}</span>
                                <span className="text-[10px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded uppercase">{issue.subcategory || 'General'}</span>
                            </div>
                            <div className="text-zinc-500 hover:text-white transition-colors">
                                {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                            </div>
                        </div>
                        
                        <div className={`text-[10px] ${theme.sub} mt-1`}>
                          {issue.description}
                        </div>

                        <div className="flex items-center gap-4 mt-2">
                            <span className="text-[10px] text-zinc-500">
                                Impact: <strong className="text-zinc-300">{issue.affected_rows} rows ({issue.affected_pct}%)</strong>
                            </span>
                            <span className="text-[10px] text-zinc-500">
                                Confidence: <strong className="text-zinc-300">{issue.confidence ? (issue.confidence * 100).toFixed(0) + '%' : 'N/A'}</strong>
                            </span>
                            {issue.fixability && (
                                <span className={`text-[10px] px-1.5 rounded border ${
                                    issue.fixability === 'auto' ? 'border-green-900/50 text-green-500' : 
                                    issue.fixability === 'review' ? 'border-yellow-900/50 text-yellow-500' : 'border-red-900/50 text-red-500'
                                }`}>
                                    {issue.fixability.toUpperCase()} FIX
                                </span>
                            )}
                        </div>
                        
                        {isExpanded && issue.risk && (
                            <div className="mt-2 p-2 bg-black/20 rounded border border-zinc-800/50 flex items-start gap-2">
                                <AlertTriangle size={12} className="text-yellow-500 mt-0.5" />
                                <div className="text-[10px] text-zinc-400">
                                    <strong className="text-zinc-300">Risk Assessment:</strong> {issue.risk}
                                </div>
                            </div>
                        )}

                        {!isExpanded && (
                            <div className={`mt-2 text-[10px] font-bold ${theme.text} flex items-center gap-1 hover:underline opacity-80`}>
                                View Evidence & Fix <ChevronDown size={10} />
                            </div>
                        )}
                      </div>
                    </div>

                    {isExpanded && issue.evidence_data && issue.evidence_columns && (
                        <EvidenceTable 
                            type={issue.category.toLowerCase().replace(/\s/g, '_')}
                            data={issue.evidence_data}
                            columns={issue.evidence_columns}
                            onExclude={() => handleExcludeRows(issue.id)}
                            onAccept={() => handleAcceptIssue(issue.id)}
                            onApplyFix={() => handleApplyFix(issue)}
                        />
                    )}
                  </div>
              );
          })}
        </div>
      </div>

      {/* AI Fix Modal */}
      {fixModalOpen && selectedIssueForFix && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm rounded-lg">
            <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-lg shadow-2xl animate-in fade-in zoom-in duration-200">
                <div className="flex items-center justify-between p-4 border-b border-zinc-800">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <Brain size={16} className="text-violet-500" /> AI Suggested Fix
                    </h3>
                    <button onClick={() => setFixModalOpen(false)} className="text-zinc-500 hover:text-white">
                        <X size={16} />
                    </button>
                </div>
                <div className="p-4">
                    <div className="mb-4">
                        <div className="text-xs text-zinc-400 mb-1">Issue: <span className="text-zinc-200 font-bold">{selectedIssueForFix.category}</span></div>
                        <div className="text-xs text-zinc-500">{selectedIssueForFix.description}</div>
                    </div>
                    
                    <div className="relative">
                        <div className="absolute top-2 right-2 text-[10px] bg-zinc-800 text-zinc-400 px-2 py-1 rounded flex items-center gap-1">
                            <Code size={10} /> Python
                        </div>
                        <pre className="bg-black border border-zinc-800 rounded-lg p-4 text-xs font-mono text-green-400 overflow-x-auto">
                            {generatePythonCode(selectedIssueForFix)}
                        </pre>
                    </div>
                </div>
                <div className="p-4 border-t border-zinc-800 flex justify-end gap-3">
                    <button 
                        onClick={() => setFixModalOpen(false)}
                        className="px-4 py-2 text-xs font-bold text-zinc-400 hover:text-white"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={applyFixCode}
                        className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 shadow-lg shadow-violet-900/20"
                    >
                        <Play size={14} /> Apply Code
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
