import React, { useState } from 'react';
import { NotebookCell, ProposedPlan, TraeRecord, EDAScope, EDAIntent, ChartProposal } from '../types';
import { Play, Edit2, CheckCircle, AlertOctagon, Terminal, FileText, Download, Trash2, Database, Brain, ArrowRight, X, Activity, Search, Plus, BarChart2, ScatterChart as ScatterIcon, PieChart, TrendingUp, AlertTriangle, List, Grid, Lock } from 'lucide-react';
import { executePlan } from '../services/executionEngine';
import { useData } from '../services/dataContext';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, Cell as RechartsCell, AreaChart, Area } from 'recharts';
import { detectColumnRole, getSmartAggregation, generateExplanation, generateEDAProposal, EDA_CONSTRAINTS } from '../services/semanticLayer';

import { QualityDiagnosticSummary } from './QualityDiagnosticSummary';

interface CellProps {
  cell: NotebookCell;
}

export const NotebookCellView: React.FC<CellProps> = ({ cell }) => {
  const { updateCell, deleteCell, dataState, registerDataset, logToTrae, approveCleaningPlan, addCell, generateAIUnderstanding, updateAIUnderstanding, confirmAIUnderstanding, updateColumnRole } = useData();
  const [isEditingPlan, setIsEditingPlan] = useState(false);
  const [isEditingUnderstanding, setIsEditingUnderstanding] = useState(false);
  const [isEditingRoles, setIsEditingRoles] = useState(false); // New
  const [localPlan, setLocalPlan] = useState(JSON.stringify(cell.plan || {}, null, 2));
  const [planSteps, setPlanSteps] = useState(cell.plan?.proposed_steps || []);
  const [rowLimit, setRowLimit] = useState<number>(10);
  
  // Helper to generate Python code for steps
  const generatePythonCode = (step: any) => {
      if (step.code) return step.code;
      
      switch(step.type) {
          case 'load_csv': return `df = pd.read_csv('${step.params?.file || 'data.csv'}')\nif 'limit' in params: df = df.head(params['limit'])`;
          case 'impute': return `df['${step.params?.column || 'col'}'].fillna('${step.params?.value || 'unknown'}', inplace=True)`;
          case 'drop_duplicates': return `df.drop_duplicates(inplace=True)`;
          case 'standardize': return `df['${step.params?.column || 'col'}'] = pd.to_numeric(df['${step.params?.column || 'col'}'], errors='coerce')`;
          case 'custom': return `# Custom Logic: ${step.description}`;
          default: return `# ${step.description}`;
      }
  };

  const [profilingColumns, setProfilingColumns] = useState([
      { name: 'order_id', type: 'string', unique: '1,231', missing: '0%' },
      { name: 'customer_email', type: 'string', unique: '1,100', missing: '3.6%', missingColor: 'text-yellow-500' },
      { name: 'amount', type: 'float', unique: '940', missing: '5.2%', missingColor: 'text-yellow-500' },
      { name: 'status', type: 'category', unique: '4', missing: '0%' },
      { name: 'created_at', type: 'datetime', unique: '1,245', missing: '0%' },
      { name: 'product_id', type: 'string', unique: '56', missing: '0%' },
      { name: 'quantity', type: 'integer', unique: '10', missing: '0%' },
      { name: 'discount', type: 'string', unique: '5', missing: '0%' },
      { name: 'shipping_city', type: 'string', unique: '45', missing: '1.2%' },
      { name: 'payment_method', type: 'category', unique: '3', missing: '0%' },
      { name: 'is_gift', type: 'boolean', unique: '2', missing: '0%' },
      { name: 'notes', type: 'string', unique: '120', missing: '85%', missingColor: 'text-red-500' },
  ]);
  
  // EDA State
   const [edaParams, setEdaParams] = useState<any>(cell.output?.params || {});
   const [edaChartData, setEdaChartData] = useState<any[]>(cell.output?.data || []);
   const [edaStats, setEdaStats] = useState<any>(cell.output?.stats || null);
 
   const handlePlanApprove = async () => {
      // 1. Execute logic
      if (cell.plan) {
          try {
              const { outputs } = await executePlan(cell.plan, dataState.datasets);
              Object.values(outputs).forEach(ds => registerDataset(ds));
          } catch (e) {
              console.error("Plan execution failed", e);
          }
      }
      // 2. Update UI
      approveCleaningPlan(cell.id, true);
  };

  const handleStepChange = (id: number, field: string, value: string) => {
      const newSteps = planSteps.map(s => s.step_id === id ? { ...s, [field]: value } : s);
      setPlanSteps(newSteps);
      if (cell.plan) {
          updateCell(cell.id, { plan: { ...cell.plan, proposed_steps: newSteps } });
      }
  };

  const removeStep = (id: number) => {
      const newSteps = planSteps.filter(s => s.step_id !== id);
      setPlanSteps(newSteps);
      if (cell.plan) {
          updateCell(cell.id, { plan: { ...cell.plan, proposed_steps: newSteps } });
      }
  };

  // RENDER PROFILING CELL
  if (cell.type === 'profiling') {
      return (
          <div className="mb-6 group animate-fade-in ml-11">
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
                   <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                       <span className="text-xs font-bold text-violet-400 flex items-center gap-2">
                           <Activity size={14} /> Data Profiling Report
                       </span>
                       <span className="text-[10px] text-zinc-500 uppercase">Read Only</span>
                   </div>
                   <div className="p-4 grid grid-cols-4 gap-4">
                       <div className="bg-black p-3 rounded border border-zinc-800 text-center">
                           <div className="text-[10px] text-zinc-500 uppercase font-bold">Total Rows</div>
                           <div className="text-xl font-mono text-white">1,245</div>
                       </div>
                       <div className="bg-black p-3 rounded border border-zinc-800 text-center">
                           <div className="text-[10px] text-zinc-500 uppercase font-bold">Columns</div>
                           <div className="text-xl font-mono text-white">12</div>
                       </div>
                       <div className="bg-black p-3 rounded border border-zinc-800 text-center">
                           <div className="text-[10px] text-zinc-500 uppercase font-bold">Missing Cells</div>
                           <div className="text-xl font-mono text-yellow-500">8.4%</div>
                       </div>
                       <div className="bg-black p-3 rounded border border-zinc-800 text-center">
                           <div className="text-[10px] text-zinc-500 uppercase font-bold">Duplicates</div>
                           <div className="text-xl font-mono text-red-500">14</div>
                       </div>
                   </div>
                   <div className="px-4 pb-4">
                       <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Column Statistics</div>
                       <div className="overflow-x-auto max-h-60 overflow-y-auto border border-zinc-800 rounded">
                           <table className="w-full text-xs text-left text-zinc-400">
                               <thead className="text-[10px] uppercase bg-zinc-950 text-zinc-500 sticky top-0">
                                   <tr>
                                       <th className="px-3 py-2 bg-zinc-950">Column</th>
                                       <th className="px-3 py-2 bg-zinc-950">Type</th>
                                       <th className="px-3 py-2 bg-zinc-950">Unique</th>
                                       <th className="px-3 py-2 bg-zinc-950">Missing</th>
                                   </tr>
                               </thead>
                               <tbody className="divide-y divide-zinc-800">
                                   {profilingColumns.map((col) => (
                                       <tr key={col.name}>
                                           <td className="px-3 py-2">{col.name}</td>
                                           <td className="px-3 py-2">
                                                <select 
                                                    value={col.type}
                                                    onChange={(e) => {
                                                        const newType = e.target.value;
                                                        setProfilingColumns(prev => prev.map(c => c.name === col.name ? { ...c, type: newType } : c));
                                                    }}
                                                    className="bg-transparent border-none text-violet-400 font-mono text-xs focus:ring-0 cursor-pointer hover:bg-zinc-800 rounded px-1 -ml-1"
                                                >
                                                    <option value="string">string</option>
                                                    <option value="integer">integer</option>
                                                    <option value="float">float</option>
                                                    <option value="boolean">boolean</option>
                                                    <option value="datetime">datetime</option>
                                                    <option value="category">category</option>
                                                </select>
                                           </td>
                                           <td className="px-3 py-2">{col.unique}</td>
                                           <td className={`px-3 py-2 ${col.missingColor || 'text-green-500'}`}>{col.missing}</td>
                                       </tr>
                                   ))}
                               </tbody>
                           </table>
                       </div>
                   </div>
              </div>
          </div>
      );
  }

  // RENDER QUALITY SUMMARY CELL
  if (cell.type === 'quality_check') {
      return <QualityDiagnosticSummary />;
  }

  // RENDER EDA CONTEXT CELL
  if (cell.type === 'eda_context') {
      const dataset = Object.values(dataState.datasets)[0]; // Use first dataset for now
      if (!dataset) return <div className="mb-6 ml-11 p-4 bg-zinc-900 border border-zinc-800 rounded-lg text-red-500">No active dataset found for analysis.</div>;

      const identifiers = dataset.columns.filter(c => c.role === 'identifier');
      const metrics = dataset.columns.filter(c => c.role === 'metric_additive' || c.role === 'metric_ratio');
      const dimensions = dataset.columns.filter(c => c.role === 'dimension');
      const timeCols = dataset.columns.filter(c => c.role === 'time');

      const renderColumnBadge = (col: any, colorClass: string) => {
          if (!isEditingRoles) {
              return (
                  <span key={col.name} className={`px-1.5 py-0.5 bg-zinc-800 ${colorClass} text-[10px] rounded flex items-center gap-1`}>
                      {col.name}
                      {col.role.includes('metric') && <span className="text-[8px] bg-zinc-700 px-1 rounded text-white">{col.role === 'metric_additive' ? 'SUM' : 'AVG'}</span>}
                  </span>
              );
          }
          
          return (
              <div key={col.name} className="relative group/role">
                  <select 
                      value={col.role}
                      onChange={(e) => updateColumnRole(dataset.name, col.name, e.target.value)}
                      className="px-1.5 py-0.5 bg-zinc-800 text-white text-[10px] rounded border border-zinc-700 focus:border-violet-500 outline-none cursor-pointer"
                  >
                      <option value="identifier">ID</option>
                      <option value="metric_additive">Metric (Sum)</option>
                      <option value="metric_ratio">Metric (Avg)</option>
                      <option value="dimension">Dim</option>
                      <option value="time">Time</option>
                  </select>
                  <div className="absolute -top-4 left-0 text-[9px] bg-black text-white px-1 rounded opacity-0 group-hover/role:opacity-100 pointer-events-none whitespace-nowrap">
                      {col.name}
                  </div>
              </div>
          );
      };

      return (
          <div className="mb-6 group animate-fade-in ml-11">
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
                  <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                      <span className="text-xs font-bold text-violet-400 flex items-center gap-2">
                          <Activity size={14} /> EDA Context & Semantics
                      </span>
                      <div className="flex items-center gap-2">
                          <span className="text-[10px] text-zinc-500 uppercase">Semantic Layer Active</span>
                          <button 
                              onClick={() => setIsEditingRoles(!isEditingRoles)}
                              className={`text-[10px] px-2 py-0.5 rounded border ${isEditingRoles ? 'bg-violet-900/30 border-violet-500 text-violet-300' : 'border-zinc-800 text-zinc-500 hover:text-zinc-300'}`}
                          >
                              {isEditingRoles ? 'Done' : 'Edit Roles'}
                          </button>
                      </div>
                  </div>
                  <div className="p-4">
                      <div className="flex items-center gap-4 mb-4">
                          <div className="p-3 bg-black rounded border border-zinc-800">
                              <div className="text-[10px] text-zinc-500 uppercase font-bold">Dataset</div>
                              <div className="text-sm font-bold text-white">{dataset.name}</div>
                          </div>
                          <div className="p-3 bg-black rounded border border-zinc-800">
                              <div className="text-[10px] text-zinc-500 uppercase font-bold">Dimensions</div>
                              <div className="text-sm font-bold text-white font-mono">{dataset.rowCount} rows × {dataset.columns.length} cols</div>
                          </div>
                      </div>
                      
                      <div className="grid grid-cols-4 gap-4">
                           <div className="bg-black/50 p-3 rounded border border-zinc-800/50">
                              <div className="text-[10px] text-zinc-500 uppercase font-bold mb-2 flex items-center gap-2 text-yellow-500"><Terminal size={12}/> Identifiers ({identifiers.length})</div>
                              <div className="flex flex-wrap gap-1">
                                  {identifiers.map(c => renderColumnBadge(c, 'text-yellow-400'))}
                              </div>
                          </div>
                          <div className="bg-black/50 p-3 rounded border border-zinc-800/50">
                              <div className="text-[10px] text-zinc-500 uppercase font-bold mb-2 flex items-center gap-2 text-green-500"><TrendingUp size={12}/> Metrics ({metrics.length})</div>
                              <div className="flex flex-wrap gap-1">
                                  {metrics.map(c => renderColumnBadge(c, 'text-green-400'))}
                              </div>
                          </div>
                          <div className="bg-black/50 p-3 rounded border border-zinc-800/50">
                              <div className="text-[10px] text-zinc-500 uppercase font-bold mb-2 flex items-center gap-2 text-blue-500"><List size={12}/> Dimensions ({dimensions.length})</div>
                              <div className="flex flex-wrap gap-1">
                                  {dimensions.map(c => renderColumnBadge(c, 'text-blue-400'))}
                              </div>
                          </div>
                          <div className="bg-black/50 p-3 rounded border border-zinc-800/50">
                              <div className="text-[10px] text-zinc-500 uppercase font-bold mb-2 flex items-center gap-2 text-purple-500"><Activity size={12}/> Time ({timeCols.length})</div>
                              <div className="flex flex-wrap gap-1">
                                  {timeCols.map(c => renderColumnBadge(c, 'text-purple-400'))}
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      );
  }

  // RENDER EDA ENTRY GATE (Strict Intent-Based)
  if (cell.type === 'eda_menu') {
      const dataset = Object.values(dataState.datasets)[0];
      const columns = dataset ? dataset.columns : [];
      const constraints = edaParams.intent ? EDA_CONSTRAINTS[edaParams.intent as EDAIntent] : null;

      const handleGenerateProposal = () => {
          if (!dataset || !edaParams.scope || !edaParams.intent) return;
          try {
              const proposal = generateEDAProposal(
                  dataset, 
                  edaParams.scope, 
                  edaParams.intent, 
                  edaParams.col1, 
                  edaParams.col2
              );
              updateCell(cell.id, { chartProposal: proposal });
          } catch (e) {
              console.error(e);
          }
      };

      const executeChart = () => {
          if (!cell.chartProposal) return;
          
          // Mock Data Generation based on Proposal
          // In a real app, this would query the engine using the proposal's axes
          const { xAxis, yAxis, chartType } = cell.chartProposal;
          let data = [];
          let stats = null;

          if (chartType === 'bar' || chartType === 'kpi') {
              data = [
                  { x: 'A', y: 450 }, { x: 'B', y: 230 }, { x: 'C', y: 180 }, { x: 'D', y: 320 }
              ];
              stats = { total: 1180, avg: 295 };
          } else if (chartType === 'line') {
              data = Array.from({ length: 12 }, (_, i) => ({
                  x: `2023-${i+1}`,
                  y: 100 + Math.random() * 50 + i * 10
              }));
              stats = { trend: 'Upward', growth: '+45%' };
          } else if (chartType === 'scatter') {
               data = Array.from({ length: 50 }, (_, i) => ({
                  x: Math.random() * 100,
                  y: Math.random() * 1000
              }));
              stats = { correlation: '0.65' };
          } else {
              // Histogram/Density
              data = Array.from({ length: 20 }, (_, i) => ({
                  x: `${i*10}-${(i+1)*10}`,
                  y: Math.floor(Math.random() * 100)
              }));
          }

          setEdaChartData(data);
          setEdaStats(stats);
          
          updateCell(cell.id, { 
              status: 'done', 
              output: { 
                  ran: true, 
                  params: edaParams, 
                  data: data, 
                  stats: stats,
                  explanation: {
                      xAxis: xAxis.column ? `${xAxis.column} (${xAxis.role})` : 'Index',
                      yAxis: yAxis.column ? `${yAxis.column} (${yAxis.aggregation.toUpperCase()})` : 'Value',
                      aggregation: yAxis.aggregation.toUpperCase(),
                      rationale: cell.chartProposal.rationale,
                      confidence: 'High'
                  }
              } 
          });
      };

      const renderAxisSelectors = () => {
          if (!constraints) return null;
          
          return (
              <div className="grid grid-cols-2 gap-4 mb-4 animate-in slide-in-from-top-2">
                  {/* X-Axis Selector */}
                  {constraints.xRole !== 'none' && (
                      <div>
                          <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">
                              X Axis ({constraints.xRole})
                          </div>
                          <select 
                              className="w-full bg-black border border-zinc-800 text-xs text-zinc-300 rounded p-2 focus:border-blue-500 outline-none"
                              value={edaParams.col1 || ""}
                              onChange={(e) => setEdaParams({ ...edaParams, col1: e.target.value })}
                          >
                              <option value="">-- Auto-Detect --</option>
                              {columns.filter(c => {
                                  // Simple role filter based on constraints
                                  if (constraints.xRole === 'time') return c.role === 'time' || c.type === 'datetime';
                                  if (constraints.xRole === 'dimension') return c.role === 'dimension' || c.role === 'identifier' || c.type === 'string';
                                  if (constraints.xRole === 'metric_additive') return c.role?.includes('metric') || ['integer','float'].includes(c.type);
                                  return true;
                              }).map(c => <option key={c.name} value={c.name}>{c.name} ({c.role})</option>)}
                          </select>
                      </div>
                  )}

                  {/* Y-Axis Selector */}
                  {constraints.yRole !== 'none' && (
                      <div>
                          <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">
                              Y Axis ({constraints.yRole})
                          </div>
                          <select 
                              className="w-full bg-black border border-zinc-800 text-xs text-zinc-300 rounded p-2 focus:border-blue-500 outline-none"
                              value={edaParams.col2 || ""}
                              onChange={(e) => setEdaParams({ ...edaParams, col2: e.target.value })}
                          >
                              <option value="">-- Auto-Detect --</option>
                              {columns.filter(c => {
                                  if (constraints.yRole === 'metric_additive') return c.role?.includes('metric') || ['integer','float'].includes(c.type);
                                  return true;
                              }).map(c => <option key={c.name} value={c.name}>{c.name} ({c.role})</option>)}
                          </select>
                      </div>
                  )}
              </div>
          );
      };

      return (
          <div className="mb-6 group animate-fade-in ml-11">
              <div className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden">
                  <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-400 flex items-center gap-2">
                          <Search size={16} /> EDA Entry Gate
                      </span>
                      <span className="text-[10px] text-zinc-500 uppercase flex items-center gap-1">
                           <Lock size={10} /> Intent Required
                      </span>
                  </div>
                  
                  <div className="p-4">
                      {/* STEP 1: SCOPE & INTENT */}
                      {cell.status === 'draft' && !cell.chartProposal ? (
                          <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                      <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">1. Analysis Scope</div>
                                      <select 
                                          className="w-full bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 rounded p-2 focus:border-blue-500 outline-none"
                                          value={edaParams.scope || ""}
                                          onChange={(e) => setEdaParams({ ...edaParams, scope: e.target.value, intent: '', col1: '', col2: '' })}
                                      >
                                          <option value="">-- Select Scope --</option>
                                          <option value="univariate">Univariate (Single Variable)</option>
                                          <option value="bivariate">Bivariate (Two Variables)</option>
                                      </select>
                                  </div>
                                  <div>
                                      <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">2. Analysis Intent</div>
                                      <select 
                                          className="w-full bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 rounded p-2 focus:border-blue-500 outline-none disabled:opacity-50"
                                          value={edaParams.intent || ""}
                                          disabled={!edaParams.scope}
                                          onChange={(e) => setEdaParams({ ...edaParams, intent: e.target.value })}
                                      >
                                          <option value="">-- Select Intent --</option>
                                          <option value="distribution">Distribution (Spread/Frequency)</option>
                                          <option value="magnitude">Magnitude (Totals/Counts)</option>
                                          <option value="comparison">Comparison (Between Groups)</option>
                                          <option value="trend">Trend (Over Time)</option>
                                          <option value="relationship">Relationship (Correlation)</option>
                                          <option value="outliers">Outliers (Anomalies)</option>
                                      </select>
                                  </div>
                              </div>

                              {/* STEP 2: AXIS SELECTION (Dynamic) */}
                              {edaParams.intent && (
                                  <div className="border-t border-zinc-800 pt-4">
                                      {renderAxisSelectors()}
                                      
                                      <div className="flex justify-end">
                                          <button 
                                              onClick={handleGenerateProposal}
                                              className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded text-xs font-bold flex items-center gap-2"
                                          >
                                              <Brain size={14} /> Review Analysis Proposal
                                          </button>
                                      </div>
                                  </div>
                              )}
                          </div>
                      ) : cell.chartProposal && !cell.output?.ran ? (
                          /* STEP 3: PROPOSAL REVIEW */
                          <div className="bg-zinc-950/50 border border-zinc-800 rounded p-4 animate-in slide-in-from-top-2">
                              <div className="flex items-center justify-between mb-4">
                                  <div className="flex items-center gap-2 text-violet-400 font-bold text-xs">
                                      <Brain size={14}/> Chart Proposal: {cell.chartProposal.chartType.toUpperCase()}
                                  </div>
                                  <div className="text-[10px] text-zinc-500 uppercase">Confidence: {cell.chartProposal.confidence}</div>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-4 mb-4">
                                  <div>
                                      <label className="text-[10px] font-bold text-zinc-500 uppercase block mb-1">X-Axis ({cell.chartProposal.xAxis.role})</label>
                                      <div className="bg-black border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-300 flex justify-between items-center">
                                          {cell.chartProposal.xAxis.column || 'Auto-Generated'}
                                          <span className="text-[10px] bg-zinc-800 px-1 rounded text-zinc-400">{cell.chartProposal.xAxis.role}</span>
                                      </div>
                                  </div>
                                  <div>
                                      <label className="text-[10px] font-bold text-zinc-500 uppercase block mb-1">Y-Axis ({cell.chartProposal.yAxis.role})</label>
                                      <div className="bg-black border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-300 flex justify-between items-center">
                                          {cell.chartProposal.yAxis.column || 'Auto-Generated'}
                                          <span className="text-[10px] bg-blue-900/30 text-blue-400 px-1 rounded border border-blue-900/50">{cell.chartProposal.yAxis.aggregation.toUpperCase()}</span>
                                      </div>
                                  </div>
                              </div>
                              
                              <div className="bg-blue-900/10 border border-blue-900/30 rounded p-3 mb-4">
                                  <div className="text-[10px] font-bold text-blue-400 uppercase mb-1">Rationale</div>
                                  <div className="text-xs text-blue-200/80">{cell.chartProposal.rationale}</div>
                              </div>
                              
                              <div className="flex justify-end gap-3">
                                  <button 
                                      onClick={() => updateCell(cell.id, { chartProposal: undefined })}
                                      className="text-zinc-500 hover:text-white text-xs font-bold px-3 py-1.5"
                                  >
                                      Back to Config
                                  </button>
                                  <button 
                                      onClick={executeChart}
                                      className="bg-green-600 hover:bg-green-500 text-white px-4 py-1.5 rounded text-xs font-bold flex items-center gap-2 shadow-lg shadow-green-900/20"
                                  >
                                      <CheckCircle size={14} /> Confirm & Plot
                                  </button>
                              </div>
                          </div>
                      ) : (
                          /* STEP 4: RESULT */
                          <div>
                              <div className="flex justify-between items-center mb-4">
                                  <div className="text-xs font-bold text-zinc-300">
                                      {edaParams.intent} Analysis
                                  </div>
                                  <button onClick={() => updateCell(cell.id, { status: 'draft', output: undefined, chartProposal: undefined })} className="text-[10px] text-zinc-500 hover:text-white flex items-center gap-1">
                                      <Edit2 size={10} /> New Analysis
                                  </button>
                              </div>
                              
                              {cell.output?.explanation && (
                                  <div className="mb-4 bg-zinc-950/50 border border-zinc-800/50 rounded p-3">
                                      <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2 flex items-center gap-2">
                                          <Brain size={12} className="text-violet-500"/> Analysis Logic
                                      </div>
                                      <div className="grid grid-cols-2 gap-4 text-xs text-zinc-400">
                                          <div><span className="text-zinc-600">X-Axis:</span> {cell.output.explanation.xAxis}</div>
                                          <div><span className="text-zinc-600">Y-Axis:</span> {cell.output.explanation.yAxis}</div>
                                          <div className="col-span-2"><span className="text-zinc-600">Rationale:</span> {cell.output.explanation.rationale}</div>
                                      </div>
                                  </div>
                              )}

                              <div className="h-64 bg-black/50 border border-zinc-800/50 rounded p-2">
                                  <ResponsiveContainer width="100%" height="100%">
                                      {cell.chartProposal?.chartType === 'line' ? (
                                          <LineChart data={edaChartData}>
                                              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                              <XAxis dataKey="x" stroke="#666" tick={{fontSize: 10}} />
                                              <YAxis stroke="#666" tick={{fontSize: 10}} />
                                              <RechartsTooltip contentStyle={{backgroundColor: '#000', border: '1px solid #333'}} />
                                              <Line type="monotone" dataKey="y" stroke="#8b5cf6" strokeWidth={2} />
                                          </LineChart>
                                      ) : cell.chartProposal?.chartType === 'scatter' ? (
                                          <ScatterChart>
                                              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                              <XAxis type="number" dataKey="x" stroke="#666" tick={{fontSize: 10}} />
                                              <YAxis type="number" dataKey="y" stroke="#666" tick={{fontSize: 10}} />
                                              <RechartsTooltip cursor={{strokeDasharray: '3 3'}} contentStyle={{backgroundColor: '#000', border: '1px solid #333'}} />
                                              <Scatter name="Data" data={edaChartData} fill="#8884d8" />
                                          </ScatterChart>
                                      ) : (
                                          <BarChart data={edaChartData}>
                                              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                              <XAxis dataKey="x" stroke="#666" tick={{fontSize: 10}} />
                                              <YAxis stroke="#666" tick={{fontSize: 10}} />
                                              <RechartsTooltip contentStyle={{backgroundColor: '#000', border: '1px solid #333'}} />
                                              <Bar dataKey="y" fill="#3b82f6" />
                                          </BarChart>
                                      )}
                                  </ResponsiveContainer>
                              </div>
                              
                              <div className="mt-2 p-3 bg-black/50 border border-zinc-800 rounded">
                                  <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2 flex items-center gap-1"><Terminal size={12}/> Generated Code</div>
                                  <div className="font-mono text-[10px] text-blue-300">
                                      # {cell.output?.explanation?.rationale}<br/>
                                      px.{cell.chartProposal?.chartType}(df, x='{cell.output.explanation.xAxis}', y='{cell.output.explanation.yAxis}').show()
                                  </div>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      );
  }

  // RENDER VALIDATION CELL
  if (cell.type === 'validation' && cell.status === 'suggested') {
       return (
          <div className="mb-6 group animate-fade-in ml-11">
              <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4">
                   <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-2">
                          <Brain size={16} className="text-green-400" />
                          <div>
                              <div className="text-sm font-bold text-zinc-200">Suggested Validation Rules</div>
                              <div className="text-xs text-zinc-500">Proposing standard checks based on column types:</div>
                          </div>
                      </div>
                  </div>
                  <div className="space-y-2 mb-4">
                      <div className="flex items-start gap-3 p-2 bg-black border border-zinc-800 rounded">
                          <input type="checkbox" defaultChecked className="mt-1 rounded bg-zinc-800 border-zinc-700 text-green-500 focus:ring-0" />
                          <div className="flex-1">
                              <div className="text-xs text-zinc-300 font-bold">order_id must be unique</div>
                              <div className="font-mono text-[10px] text-zinc-500 mt-1 flex items-center gap-1">
                                  <Terminal size={10}/> assert df['order_id'].is_unique
                              </div>
                          </div>
                      </div>
                      <div className="flex items-start gap-3 p-2 bg-black border border-zinc-800 rounded">
                          <input type="checkbox" defaultChecked className="mt-1 rounded bg-zinc-800 border-zinc-700 text-green-500 focus:ring-0" />
                          <div className="flex-1">
                              <div className="text-xs text-zinc-300 font-bold">amount must be greater than 0</div>
                              <div className="font-mono text-[10px] text-zinc-500 mt-1 flex items-center gap-1">
                                  <Terminal size={10}/> assert (df['amount'] &gt; 0).all()
                              </div>
                          </div>
                      </div>
                      <div className="flex items-start gap-3 p-2 bg-black border border-zinc-800 rounded">
                          <input type="checkbox" defaultChecked className="mt-1 rounded bg-zinc-800 border-zinc-700 text-green-500 focus:ring-0" />
                          <div className="flex-1">
                              <div className="text-xs text-zinc-300 font-bold">customer_email must match email format</div>
                              <div className="font-mono text-[10px] text-zinc-500 mt-1 flex items-center gap-1">
                                  <Terminal size={10}/> assert df['customer_email'].str.match(r'^[\w\.-]+@[\w\.-]+\.\w+$').all()
                              </div>
                          </div>
                      </div>
                  </div>
                  <div className="flex justify-end gap-2 border-t border-zinc-800 pt-4">
                       <button className="px-3 py-1.5 text-xs font-bold text-zinc-500 hover:text-white">Add Rule</button>
                       <button onClick={() => updateCell(cell.id, { status: 'done', output: { logs: ['Validation Passed'], outputs: {}, validation: { steps_validated: 3 } } })} className="bg-green-600 hover:bg-green-500 text-white px-4 py-1.5 rounded text-xs font-bold flex items-center gap-2">
                           <Play size={14} /> Run Checks
                       </button>
                  </div>
              </div>
          </div>
       );
  }

  // RENDER CLEANING PLAN CELL
  if (cell.type === 'cleaning_plan') {
       return (
          <div className="mb-6 group animate-fade-in ml-11">
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
                   <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                       <span className="text-xs font-bold text-violet-400 flex items-center gap-2">
                           <Brain size={14} /> Recommended Cleaning Plan
                       </span>
                       <span className="text-[10px] bg-yellow-900/30 text-yellow-500 px-2 py-0.5 rounded border border-yellow-900/50">
                           WAITING APPROVAL
                       </span>
                   </div>
                   <div className="p-4">
                       <div className="text-xs text-zinc-400 mb-4">
                           Based on the diagnostic above, I recommend the following ordered steps. Each step will be executed in its own cell for verification.
                       </div>
                       
                       <div className="space-y-2 mb-4">
                           {planSteps.map((step) => (
                               <div key={step.step_id} className="flex items-center gap-3 p-2 bg-black border border-zinc-800 rounded opacity-90 group/step">
                                   <div className="w-5 h-5 rounded-full bg-zinc-800 flex items-center justify-center text-[10px] font-bold text-zinc-500">{step.step_id}</div>
                                   {isEditingPlan ? (
                                       <input 
                                           className="flex-1 bg-zinc-900 border border-zinc-700 text-xs text-zinc-300 px-2 py-1 rounded focus:outline-none focus:border-violet-500"
                                           value={step.description}
                                           onChange={(e) => handleStepChange(step.step_id, 'description', e.target.value)}
                                       />
                                   ) : (
                                       <div className="flex-1">
                                           <div className="text-xs text-zinc-300 font-bold mb-1">{step.description}</div>
                                           <div className="font-mono text-[10px] text-zinc-400 bg-zinc-900/50 p-1.5 rounded border border-zinc-800/50 flex items-center gap-2">
                                               <Terminal size={10} className="text-violet-500" />
                                               {generatePythonCode(step)}
                                           </div>
                                       </div>
                                   )}
                                   {isEditingPlan && (
                                       <button onClick={() => removeStep(step.step_id)} className="text-zinc-600 hover:text-red-500"><X size={14}/></button>
                                   )}
                               </div>
                           ))}
                           
                           {isEditingPlan && (
                               <button 
                                   onClick={() => {
                                        const newId = Math.max(...planSteps.map(s => s.step_id), 0) + 1;
                                        const newStep = { step_id: newId, type: 'custom' as const, description: "New cleaning step", params: {} };
                                        setPlanSteps([...planSteps, newStep]);
                                   }}
                                   className="w-full py-2 border border-dashed border-zinc-800 text-xs text-zinc-500 hover:text-zinc-300 hover:border-zinc-600 rounded flex items-center justify-center gap-2"
                               >
                                   <Activity size={12} /> Add Step
                               </button>
                           )}
                       </div>

                       <div className="flex justify-end gap-2 border-t border-zinc-800 pt-4">
                           <button 
                               onClick={() => setIsEditingPlan(!isEditingPlan)}
                               className={`px-3 py-1.5 text-xs font-bold ${isEditingPlan ? 'text-violet-400 bg-violet-900/20' : 'text-zinc-500 hover:text-zinc-300'} rounded transition-colors`}
                           >
                               {isEditingPlan ? 'Done Editing' : 'Modify Plan'}
                           </button>
                           {!isEditingPlan && (
                               <button 
                                   onClick={handlePlanApprove}
                                   className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-1.5 rounded text-xs font-bold flex items-center gap-2"
                               >
                                   <CheckCircle size={14} /> Approve Plan
                               </button>
                           )}
                       </div>
                   </div>
              </div>
          </div>
       );
  }

  // RENDER CLEANING STEP EXECUTION CELL
  if (cell.type === 'cleaning_step') {
       return (
          <div className="mb-6 group animate-fade-in ml-11">
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
                   <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                       <span className="text-xs font-bold text-zinc-300 flex items-center gap-2">
                           <Terminal size={14} className="text-violet-500" /> 
                           Cleaning Step {cell.plan?.proposed_steps[0]?.step_id || ''}
                       </span>
                       {cell.status === 'draft' && <span className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded">PENDING</span>}
                       {cell.status === 'done' && <span className="text-[10px] bg-green-900/30 text-green-500 px-2 py-0.5 rounded border border-green-900/50">APPLIED</span>}
                       {cell.status === 'stale' && <span className="text-[10px] bg-yellow-900/30 text-yellow-500 px-2 py-0.5 rounded border border-yellow-900/50">STALE</span>}
                   </div>
                   <div className="p-4">
                       <div className="flex items-start gap-4 mb-4">
                           <div className="flex-1">
                               <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Action</div>
                               <div className="text-sm font-mono text-zinc-200 bg-black p-2 rounded border border-zinc-800">
                                   {cell.input}
                               </div>
                           </div>
                       </div>

                       {/* Detailed Action Info */}
                       <div className="grid grid-cols-2 gap-4 mb-4 bg-zinc-950/50 p-3 rounded border border-zinc-800/50">
                           <div>
                               <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Why (Rationale)</div>
                               <div className="text-xs text-zinc-400">
                                   {cell.plan?.rationale || "Improve data quality and consistency."}
                               </div>
                           </div>
                           <div>
                               <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Impact Analysis</div>
                               <div className="text-xs text-zinc-400">
                                   Modifies <b>{cell.plan?.proposed_steps[0]?.params?.column || 'target column'}</b>. 
                                   Ensures valid format and removes anomalies.
                               </div>
                           </div>
                       </div>

                       {/* Preview Diff */}
                       <div className="grid grid-cols-2 gap-4 mb-4">
                           <div>
                               <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Before (Preview)</div>
                               <div className="bg-black border border-zinc-800 rounded p-2 text-xs font-mono text-red-300/70 h-24 overflow-y-auto">
                                   <div className="opacity-50">row_14: "dup_email@test.com"</div>
                                   <div className="opacity-50">row_15: "dup_email@test.com"</div>
                                   <div>row_45: null</div>
                               </div>
                           </div>
                           <div>
                               <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">After (Preview)</div>
                               <div className="bg-black border border-zinc-800 rounded p-2 text-xs font-mono text-green-300/70 h-24 overflow-y-auto">
                                   <div className="opacity-50">row_14: "dup_email@test.com"</div>
                                   <div className="opacity-50 line-through decoration-red-500">row_15: "dup_email@test.com"</div>
                                   <div>row_45: "unknown"</div>
                               </div>
                           </div>
                       </div>

                       <div className="flex justify-end gap-2 border-t border-zinc-800 pt-4">
                           {cell.status === 'done' ? (
                               <button 
                                   onClick={() => updateCell(cell.id, { status: 'draft' })}
                                   className="text-zinc-400 hover:text-white px-4 py-1.5 rounded text-xs font-bold flex items-center gap-2 border border-zinc-700 hover:bg-zinc-800"
                               >
                                   <X size={14} /> Revert Action
                               </button>
                           ) : (
                               <button 
                                   onClick={() => updateCell(cell.id, { status: 'done' })}
                                   className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-1.5 rounded text-xs font-bold flex items-center gap-2"
                               >
                                   <Play size={14} /> Apply Transformation
                               </button>
                           )}
                       </div>
                   </div>
              </div>
          </div>
       );
  }

  const handleIngest = async () => {
      const plan: ProposedPlan = {
          intent: cell.input || "Load data",
          rationale: "Loading local file with user-defined row limit.",
          proposed_steps: [
              { 
                  step_id: 1, 
                  description: `Load ${rowLimit === -1 ? 'all' : rowLimit} rows from source`, 
                  type: "load_csv",
                  params: { limit: rowLimit }
              }
          ],
          assumptions: ["File is valid CSV"],
          risks: []
      };

      updateCell(cell.id, { plan, status: 'executing' });
      
      try {
          const { outputs, logs, validation } = await executePlan(plan, dataState.datasets);
          
          Object.values(outputs).forEach(ds => registerDataset(ds));

          // Generate AI Understanding
          const dataset = Object.values(outputs)[0];
          const understanding = generateAIUnderstanding(dataset);

          updateCell(cell.id, { 
              status: 'done', 
              output: { logs, outputs, validation },
              aiUnderstanding: understanding 
          });
          
          // Log to TRAE (Audit)
          const record: TraeRecord = {
              session_id: 'sess_1',
              cell_id: cell.id,
              timestamp: new Date().toISOString(),
              user_prompt: cell.input || '',
              ai_rationale: plan.rationale,
              proposed_steps: plan.proposed_steps,
              approved_by_user: true,
              executed_queries: logs, 
              validation_results: validation,
              outputs_generated: Object.keys(outputs)
          };
          logToTrae(record);

      } catch (e: any) {
          updateCell(cell.id, { status: 'error', output: { error: e.message } });
      }
  };

  const handlePropose = async () => {
      if (!cell.input) return;
      
      // Simulate LLM Plan Generation
      const plan: ProposedPlan = {
          intent: cell.input,
          rationale: "Based on the request, we should standardize the data format and validate consistency.",
          proposed_steps: [
              { step_id: 1, description: "Load and validate source data", type: "load_csv" },
              { step_id: 2, description: "Create standardized table structure", type: "create_table", name: "clean_data" }
          ],
          assumptions: ["Source is CSV format", "Data contains header row"],
          risks: ["Missing values might be dropped"]
      };

      updateCell(cell.id, { plan, status: 'suggested' });
      setLocalPlan(JSON.stringify(plan, null, 2));
  };

  const handleApproveAndRun = async () => {
      if (!cell.plan) return;

      updateCell(cell.id, { status: 'executing' });
      
      try {
          let plan: ProposedPlan = cell.plan;
          
          if (isEditingPlan) {
              try {
                  plan = JSON.parse(localPlan);
                  updateCell(cell.id, { plan }); 
              } catch (e) {
                  alert("Invalid JSON Plan");
                  updateCell(cell.id, { status: 'error' });
                  return;
              }
          }

          const { outputs, logs, validation } = await executePlan(plan, dataState.datasets);
          
          Object.values(outputs).forEach(ds => registerDataset(ds));

          updateCell(cell.id, { status: 'done', output: { logs, outputs, validation } });
          
          // Log to TRAE (Audit)
          const record: TraeRecord = {
              session_id: 'sess_1',
              cell_id: cell.id,
              timestamp: new Date().toISOString(),
              user_prompt: cell.input || '',
              ai_rationale: plan.rationale,
              proposed_steps: plan.proposed_steps,
              approved_by_user: true,
              executed_queries: logs, // Simplified
              validation_results: validation,
              outputs_generated: Object.keys(outputs)
          };
          logToTrae(record);

      } catch (e: any) {
          updateCell(cell.id, { status: 'error', output: { error: e.message } });
      }
  };

  return (
    <div className="mb-6 group animate-fade-in">
      {/* 1. Cell Input (Prompt) */}
      <div className="flex items-start gap-3 mb-2">
          <div className="w-8 flex justify-center pt-2">
              <div className={`w-2 h-2 rounded-full transition-colors ${
                  cell.status === 'done' ? 'bg-green-500' :
                  cell.status === 'executing' ? 'bg-violet-500 animate-pulse' :
                  cell.status === 'error' ? 'bg-red-500' :
                  'bg-zinc-700'
              }`}></div>
          </div>
          <div className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden focus-within:border-violet-500 transition-colors">
              <div className="flex items-center bg-zinc-950/50 px-3 py-2 border-b border-zinc-800/50">
                  <span className="text-[10px] font-bold uppercase text-zinc-500 tracking-wider mr-auto flex items-center gap-2">
                      {cell.type.toUpperCase()} CELL
                      {cell.status === 'suggested' && <span className="text-yellow-500 bg-yellow-900/20 px-1.5 py-0.5 rounded text-[9px]">WAITING APPROVAL</span>}
                  </span>
                  <div className="flex items-center gap-1">
                      <button onClick={() => deleteCell(cell.id)} className="p-1 hover:text-red-400 text-zinc-600"><Trash2 size={12}/></button>
                  </div>
              </div>
              <div className="p-3">
                  {cell.type === 'ingest' && !cell.input && (
                      <div className="mb-4">
                          <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Select Data Source</div>
                          <div className="grid grid-cols-3 gap-2 mb-3">
                              <div className="relative group">
                                  <button onClick={() => {
                                      const fileInput = document.getElementById(`file-upload-${cell.id}`);
                                      if (fileInput) fileInput.click();
                                  }} className="w-full flex flex-col items-center gap-2 p-3 bg-zinc-950 border border-zinc-800 hover:border-violet-500 rounded-lg transition-all">
                                      <FileText className="text-zinc-500 group-hover:text-violet-500" size={20} />
                                      <span className="text-[10px] font-bold text-zinc-400">Local File</span>
                                  </button>
                                  <input 
                                      type="file" 
                                      id={`file-upload-${cell.id}`}
                                      className="hidden" 
                                      onChange={(e) => {
                                          if (e.target.files?.[0]) {
                                              updateCell(cell.id, { 
                                                  input: `Load file: ${e.target.files[0].name}`,
                                                  status: 'draft' 
                                              });
                                          }
                                      }}
                                  />
                              </div>
                              <button onClick={() => updateCell(cell.id, { input: "Connect to Data Warehouse", status: 'draft' })} className="flex flex-col items-center gap-2 p-3 bg-zinc-950 border border-zinc-800 hover:border-blue-500 rounded-lg transition-all group">
                                  <Database className="text-zinc-500 group-hover:text-blue-500" size={20} />
                                  <span className="text-[10px] font-bold text-zinc-400">Warehouse</span>
                              </button>
                              <button onClick={() => updateCell(cell.id, { input: "Connect to SQL Server", status: 'draft' })} className="flex flex-col items-center gap-2 p-3 bg-zinc-950 border border-zinc-800 hover:border-green-500 rounded-lg transition-all group">
                                  <Terminal className="text-zinc-500 group-hover:text-green-500" size={20} />
                                  <span className="text-[10px] font-bold text-zinc-400">SQL Server</span>
                              </button>
                              <button onClick={() => updateCell(cell.id, { input: "Connect to Data Lake (S3)", status: 'draft' })} className="flex flex-col items-center gap-2 p-3 bg-zinc-950 border border-zinc-800 hover:border-cyan-500 rounded-lg transition-all group">
                                  <Database className="text-zinc-500 group-hover:text-cyan-500" size={20} />
                                  <span className="text-[10px] font-bold text-zinc-400">Data Lake</span>
                              </button>
                              <button onClick={() => updateCell(cell.id, { input: "Connect to Streaming Source (Kafka)", status: 'draft' })} className="flex flex-col items-center gap-2 p-3 bg-zinc-950 border border-zinc-800 hover:border-orange-500 rounded-lg transition-all group">
                                  <Activity className="text-zinc-500 group-hover:text-orange-500" size={20} />
                                  <span className="text-[10px] font-bold text-zinc-400">Streaming</span>
                              </button>
                          </div>
                          <div className="relative mb-3">
                               <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-zinc-800"></div></div>
                               <div className="relative flex justify-center text-[10px] uppercase"><span className="bg-zinc-900 px-2 text-zinc-600">Or describe manually</span></div>
                          </div>
                      </div>
                  )}

                  <input 
                      className="w-full bg-transparent text-sm text-zinc-200 focus:outline-none font-mono placeholder-zinc-600"
                      placeholder={`Enter instruction for ${cell.type} (e.g. "Clean missing values")...`}
                      value={cell.input || ''}
                      readOnly={cell.status === 'executing' || cell.status === 'done'}
                      onChange={(e) => updateCell(cell.id, { input: e.target.value, status: 'draft' })}
                      onKeyDown={(e) => {
                          if (e.key === 'Enter' && cell.status === 'draft') handlePropose();
                      }}
                  />
              </div>
          </div>
      </div>

      {/* 2. AI Suggestion (Proposed Plan) */}
      {(cell.status === 'suggested' || cell.status === 'approved' || cell.status === 'executing' || cell.status === 'done' || cell.status === 'stale') && cell.plan && cell.type !== 'ingest' && (
          <div className="ml-11 mb-2">
              <div className={`bg-zinc-950 border rounded-lg p-4 relative ${cell.status === 'stale' ? 'border-yellow-800/50 opacity-70' : 'border-zinc-800'}`}>
                  
                  {cell.status === 'stale' && (
                      <div className="absolute top-0 right-0 bg-yellow-900/50 text-yellow-500 text-[10px] font-bold px-2 py-1 rounded-bl-lg border-b border-l border-yellow-800/50 flex items-center gap-1">
                          <AlertOctagon size={12} /> STALE - Upstream changed
                      </div>
                  )}
                  <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-2">
                          <Brain size={16} className="text-violet-400" />
                          <div>
                              <div className="text-sm font-bold text-zinc-200">Proposed Strategy</div>
                              <div className="text-xs text-zinc-500">{cell.plan.rationale}</div>
                          </div>
                      </div>
                      {cell.status === 'suggested' && (
                          <button 
                              onClick={() => setIsEditingPlan(!isEditingPlan)}
                              className="text-xs text-zinc-500 hover:text-white flex items-center gap-1 bg-zinc-900 px-2 py-1 rounded border border-zinc-800"
                          >
                              <Edit2 size={10} /> {isEditingPlan ? 'Save Edits' : 'Edit Plan'}
                          </button>
                      )}
                  </div>

                  {isEditingPlan ? (
                      <textarea 
                          className="w-full h-48 bg-black border border-zinc-800 rounded p-3 text-xs font-mono text-green-400 focus:outline-none focus:border-violet-500"
                          value={localPlan}
                          onChange={(e) => setLocalPlan(e.target.value)}
                      />
                  ) : (
                      <div className="space-y-3">
                          <div className="bg-zinc-900/50 rounded border border-zinc-800/50 p-3">
                              <div className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Execution Steps</div>
                              <div className="space-y-2">
                                  {cell.plan.proposed_steps.map((step, i) => (
                                      <div key={i} className="flex items-start gap-3 text-xs text-zinc-300">
                                          <div className="w-5 h-5 rounded-full bg-zinc-800 flex items-center justify-center text-[10px] font-bold text-zinc-500 flex-shrink-0">
                                              {step.step_id}
                                          </div>
                                          <div>
                                              <div className="font-medium">{step.description}</div>
                                              <div className="font-mono text-[10px] text-zinc-500 mt-0.5 bg-black/50 px-1.5 py-0.5 rounded inline-block">
                                                  {step.type}
                                              </div>
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </div>
                          
                          <div className="flex gap-4">
                              <div className="flex-1">
                                  <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Assumptions</div>
                                  <ul className="list-disc list-inside text-xs text-zinc-400">
                                      {cell.plan.assumptions.map((a, i) => <li key={i}>{a}</li>)}
                                  </ul>
                              </div>
                              <div className="flex-1">
                                  <div className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Risks</div>
                                  <ul className="list-disc list-inside text-xs text-red-400/80">
                                      {cell.plan.risks.map((r, i) => <li key={i}>{r}</li>)}
                                  </ul>
                              </div>
                          </div>
                      </div>
                  )}

                  {cell.status === 'suggested' && (
                      <div className="mt-4 flex items-center justify-end gap-3 pt-4 border-t border-zinc-800">
                          <span className="text-xs text-zinc-500 mr-auto italic">Review steps above carefully before approving.</span>
                          <button className="px-3 py-1.5 text-xs font-bold text-zinc-400 hover:text-white">Cancel</button>
                          <button 
                              onClick={handleApproveAndRun}
                              className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 shadow-lg shadow-violet-900/20"
                          >
                              <CheckCircle size={14} /> Approve & Execute
                          </button>
                      </div>
                  )}

                  {cell.status === 'stale' && (
                      <div className="mt-4 flex items-center justify-end gap-3 pt-4 border-t border-zinc-800">
                          <span className="text-xs text-yellow-500 mr-auto italic">Data dependencies have changed.</span>
                          <button 
                              onClick={handleApproveAndRun}
                              className="bg-yellow-600 hover:bg-yellow-500 text-black px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2"
                          >
                              <Activity size={14} /> Re-Run Cell
                          </button>
                      </div>
                  )}
              </div>
          </div>
      )}

      {/* 2.5 Ingest Specific UI (Pre-load) */}
      {cell.type === 'ingest' && (cell.status === 'suggested' || cell.status === 'draft') && cell.input && cell.input.includes('Load file:') && (
          <div className="ml-11 mb-2">
              <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-zinc-900 rounded flex items-center justify-center">
                              <FileText className="text-violet-500" size={20} />
                          </div>
                          <div>
                              <div className="text-sm font-bold text-zinc-200">Ready to Load</div>
                              <div className="text-xs text-zinc-500">{cell.input.replace('Load file: ', '')}</div>
                          </div>
                      </div>
                  </div>
                  
                  <div className="flex items-center gap-4 bg-black/40 p-3 rounded border border-zinc-800/50 mb-4">
                      <div className="text-[10px] uppercase font-bold text-zinc-500">Preview Settings:</div>
                      <div className="flex items-center gap-2">
                          {[10, 100, -1].map((limit) => (
                              <button
                                  key={limit}
                                  onClick={() => setRowLimit(limit)}
                                  className={`px-3 py-1 text-xs font-bold rounded border transition-colors ${
                                      rowLimit === limit 
                                          ? 'bg-violet-600 border-violet-500 text-white' 
                                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                                  }`}
                              >
                                  {limit === -1 ? 'Entire Data' : `${limit} Rows`}
                              </button>
                          ))}
                      </div>
                  </div>

                  <div className="flex justify-end">
                      <button 
                          onClick={handleIngest}
                          className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2"
                      >
                          <Play size={14} /> Load & Preview Data
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* 2.6 AI Understanding Summary (Auto-Generated) */}
      {cell.aiUnderstanding && (
          <div className="ml-11 mb-6 animate-fade-in">
              <div className={`bg-zinc-950 border rounded-lg overflow-hidden ${cell.aiUnderstanding.userConfirmed ? 'border-green-900/30' : 'border-violet-500/30 ring-1 ring-violet-500/20'}`}>
                   <div className={`px-4 py-2 border-b flex items-center justify-between ${cell.aiUnderstanding.userConfirmed ? 'bg-green-900/10 border-green-900/30' : 'bg-violet-900/10 border-violet-500/30'}`}>
                       <span className={`text-xs font-bold flex items-center gap-2 ${cell.aiUnderstanding.userConfirmed ? 'text-green-400' : 'text-violet-400'}`}>
                           <Brain size={14} /> AI Understanding Summary
                           {cell.aiUnderstanding.userConfirmed && <span className="text-[10px] bg-green-900/30 text-green-500 px-2 py-0.5 rounded border border-green-900/50 flex items-center gap-1"><CheckCircle size={10}/> Confirmed</span>}
                       </span>
                       <span className="text-[10px] text-zinc-500 uppercase">Confidence: <span className="text-white">{cell.aiUnderstanding.confidence}</span></span>
                   </div>
                   
                   <div className="p-4">
                       {isEditingUnderstanding ? (
                           <div className="space-y-4">
                               <div>
                                   <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Domain / Context</label>
                                   <input 
                                       className="w-full bg-black border border-zinc-800 text-xs text-zinc-300 px-2 py-1.5 rounded focus:border-violet-500 outline-none"
                                       value={cell.aiUnderstanding.domainGuess}
                                       onChange={(e) => updateAIUnderstanding(cell.id, { ...cell.aiUnderstanding!, domainGuess: e.target.value })}
                                   />
                               </div>
                               <div>
                                   <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Target Variable</label>
                                   <input 
                                       className="w-full bg-black border border-zinc-800 text-xs text-zinc-300 px-2 py-1.5 rounded focus:border-violet-500 outline-none"
                                       value={cell.aiUnderstanding.targetVariable}
                                       onChange={(e) => updateAIUnderstanding(cell.id, { ...cell.aiUnderstanding!, targetVariable: e.target.value })}
                                   />
                               </div>
                               <div className="flex justify-end gap-2 pt-2">
                                   <button 
                                       onClick={() => setIsEditingUnderstanding(false)}
                                       className="px-3 py-1.5 text-xs font-bold text-zinc-400 hover:text-white"
                                   >
                                       Cancel
                                   </button>
                                   <button 
                                       onClick={() => setIsEditingUnderstanding(false)}
                                       className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-1.5 rounded text-xs font-bold"
                                   >
                                       Save Changes
                                   </button>
                               </div>
                           </div>
                       ) : (
                           <>
                               <div className="text-sm text-zinc-300 mb-4 leading-relaxed">
                                   I have analyzed the dataset. It appears to be related to <b className="text-white">{cell.aiUnderstanding.domainGuess}</b> data.
                                   I detected <b className="text-white">{cell.aiUnderstanding.rows}</b> rows and <b className="text-white">{cell.aiUnderstanding.columns}</b> columns.
                               </div>
                               
                               <div className="grid grid-cols-2 gap-4 mb-4">
                                   <div className="bg-black/40 p-3 rounded border border-zinc-800/50">
                                       <div className="text-[10px] uppercase font-bold text-zinc-500 mb-2">Key Identifiers</div>
                                       <div className="flex flex-wrap gap-1">
                                           {cell.aiUnderstanding.keyIdentifiers.length > 0 ? (
                                               cell.aiUnderstanding.keyIdentifiers.map(k => <span key={k} className="px-1.5 py-0.5 bg-zinc-800 text-zinc-400 text-[10px] rounded font-mono">{k}</span>)
                                           ) : <span className="text-xs text-zinc-600 italic">None detected</span>}
                                       </div>
                                   </div>
                                   <div className="bg-black/40 p-3 rounded border border-zinc-800/50">
                                       <div className="text-[10px] uppercase font-bold text-zinc-500 mb-2">Initial Concerns</div>
                                       <ul className="list-disc list-inside text-xs text-yellow-500/80">
                                           {cell.aiUnderstanding.concerns.map((c, i) => <li key={i}>{c}</li>)}
                                       </ul>
                                   </div>
                               </div>

                               {!cell.aiUnderstanding.userConfirmed && (
                                   <div className="flex items-center justify-between pt-4 border-t border-zinc-800/50">
                                       <span className="text-[10px] text-zinc-500 italic">Please confirm my understanding before proceeding.</span>
                                       <div className="flex gap-2">
                                           <button 
                                               onClick={() => setIsEditingUnderstanding(true)}
                                               className="text-zinc-400 hover:text-white px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1 hover:bg-zinc-800"
                                           >
                                               <Edit2 size={12} /> Correct
                                           </button>
                                           <button 
                                               onClick={() => confirmAIUnderstanding(cell.id)}
                                               className="bg-green-600 hover:bg-green-500 text-white px-4 py-1.5 rounded text-xs font-bold flex items-center gap-1 shadow-lg shadow-green-900/20"
                                           >
                                               <CheckCircle size={14} /> Confirm
                                           </button>
                                       </div>
                                   </div>
                               )}
                           </>
                       )}
                   </div>
              </div>
          </div>
      )}

                          {/* 3. Output Renderer */}
      {cell.status === 'done' && cell.output && (
          <div className="ml-11 bg-zinc-900/20 border border-zinc-800 rounded-lg p-4 animate-fade-in relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-green-500/50"></div>
              
              <div className="flex items-center gap-2 mb-4">
                  <CheckCircle size={16} className="text-green-500" />
                  <span className="text-sm font-bold text-zinc-200">Execution Successful</span>
              </div>

              {/* Data Preview Table for Ingest */}
              {cell.type === 'ingest' && cell.output.outputs && Object.values(cell.output.outputs).length > 0 && (
                  <div className="mb-4">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-2">Data Preview</div>
                      <div className="overflow-x-auto border border-zinc-800 rounded-lg">
                          <table className="w-full text-xs text-left text-zinc-300">
                              <thead className="text-[10px] uppercase bg-black text-zinc-500">
                                  <tr>
                                      {(Object.values(cell.output.outputs)[0] as any).columns.map((col: any) => (
                                          <th key={col.name} className="px-3 py-2 border-b border-zinc-800">{col.name}</th>
                                      ))}
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-800 bg-zinc-900/50">
                                  {(Object.values(cell.output.outputs)[0] as any).rows.slice(0, 10).map((row: any, i: number) => (
                                      <tr key={i} className="hover:bg-zinc-800/50">
                                          {(Object.values(cell.output.outputs)[0] as any).columns.map((col: any) => (
                                              <td key={col.name} className="px-3 py-2">{row[col.name]}</td>
                                          ))}
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      </div>
                      <div className="text-[10px] text-zinc-500 mt-2 text-right">
                          Showing first {(Object.values(cell.output.outputs)[0] as any).rows.slice(0, 10).length} rows of {(Object.values(cell.output.outputs)[0] as any).rowCount} total
                      </div>
                  </div>
              )}

              {cell.type !== 'ingest' && (
              <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-black/40 p-3 rounded border border-zinc-800/50">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Validation Results</div>
                      <div className="text-xs text-zinc-300">
                          <div className="flex justify-between mb-1">
                              <span>Steps Validated:</span>
                              <span className="font-mono text-green-400">{cell.output.validation.steps_validated}</span>
                          </div>
                          <div className="flex justify-between">
                              <span>Schema Checks:</span>
                              <span className="font-mono text-green-400">PASSED</span>
                          </div>
                      </div>
                  </div>
                  <div className="bg-black/40 p-3 rounded border border-zinc-800/50">
                      <div className="text-[10px] uppercase font-bold text-zinc-500 mb-1">Output Artifacts</div>
                      <div className="space-y-1">
                          {Object.keys(cell.output.outputs).map(name => (
                              <div key={name} className="flex items-center justify-between text-xs text-zinc-300">
                                  <span className="flex items-center gap-1"><Database size={10} /> {name}</span>
                                  <button className="text-violet-400 hover:underline flex items-center gap-1">
                                      <Download size={10} /> CSV
                                  </button>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>
              )}

              {cell.output.logs && (
                  <div className="text-[10px] font-mono text-zinc-500 bg-black p-2 rounded border border-zinc-800 max-h-32 overflow-y-auto">
                      {cell.output.logs.map((log: string, i: number) => (
                          <div key={i} className="flex gap-2">
                              <span className="text-zinc-700">{i+1}.</span>
                              <span>{log}</span>
                          </div>
                      ))}
                  </div>
              )}
          </div>
      )}
    </div>
  );
};
