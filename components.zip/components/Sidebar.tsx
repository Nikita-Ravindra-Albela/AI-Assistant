import React from 'react';
import { LayoutDashboard, Database, Eraser, ShieldCheck, GitCommit, FileText, Settings, Search, Terminal } from 'lucide-react';
import { AppMode } from '../types';

interface SidebarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  appMode: AppMode;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, appMode }) => {
  const menuItems = [
    { id: 'notebook', label: 'Notebook', icon: Terminal, section: 'WORKSPACE' },
    { id: 'lineage', label: 'Lineage & History', icon: GitCommit, section: 'GOVERNANCE' },
  ];

  return (
    <div className="w-64 bg-zinc-950 border-r border-zinc-800 flex flex-col h-full">
      {/* Logo */}
      <div className="h-16 flex items-center px-6 border-b border-zinc-800">
        <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center mr-3">
          <Database className="text-white" size={18} />
        </div>
        <span className="font-bold text-lg text-white tracking-tight">DataWise Local AI</span>
      </div>

      {/* Menu */}
      <div className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
        {['WORKSPACE', 'GOVERNANCE'].map(section => (
          <div key={section} className="mb-6">
            <div className="px-3 mb-2 text-[10px] font-bold text-zinc-600 uppercase tracking-wider">{section}</div>
            {menuItems.filter(item => item.section === section).map(item => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentView === item.id 
                    ? 'bg-violet-600/10 text-violet-400 border border-violet-600/20' 
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                }`}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            ))}
          </div>
        ))}
      </div>

      {/* User */}
      <div className="p-4 border-t border-zinc-800">
        <div className="flex items-center gap-3 p-2 rounded-lg bg-zinc-900/50 border border-zinc-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-violet-500 to-fuchsia-500"></div>
          <div>
            <div className="text-sm font-bold text-zinc-200">Admin User</div>
            <div className="text-xs text-zinc-500">Senior Analyst</div>
          </div>
        </div>
      </div>
    </div>
  );
};
