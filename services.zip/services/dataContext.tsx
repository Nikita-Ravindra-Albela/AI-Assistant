import React, { createContext, useContext, useState, ReactNode } from 'react';
import { TableSchema, LineageEvent, NotebookCell, Dataset, TraeRecord, DatasetVersion, ProposedPlan, AIUnderstanding, LineageEntry } from '../types';
import { detectColumnRole } from './semanticLayer';

interface DataState {
  datasets: Record<string, Dataset>;
  datasetVersions: Record<string, DatasetVersion>; // Added for versioning
  activeDatasetId: string | null;
}

interface DataContextType {
  dataState: DataState;
  cells: NotebookCell[];
  history: LineageEvent[];
  traeRecords: TraeRecord[];
  lineage: LineageEntry[]; // New: Full Lineage Log
  addCell: (type: NotebookCell['type'], input?: string) => void;
  updateCell: (id: string, updates: Partial<NotebookCell>) => void;
  deleteCell: (id: string) => void;
  registerDataset: (dataset: Dataset, versionInfo?: { derivedFrom?: string, changes?: string[] }) => void;
  logToTrae: (record: TraeRecord) => void;
  approveCleaningPlan: (id: string, autoRun?: boolean) => void;
  generateAIUnderstanding: (dataset: Dataset) => AIUnderstanding; 
  updateAIUnderstanding: (cellId: string, understanding: AIUnderstanding) => void;
  confirmAIUnderstanding: (cellId: string) => void;
  addLineageEntry: (entry: Omit<LineageEntry, 'id' | 'timestamp'>) => string;
  updateColumnRole: (datasetName: string, columnName: string, newRole: string) => void; // New
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [dataState, setDataState] = useState<DataState>({
    datasets: {},
    datasetVersions: {},
    activeDatasetId: null
  });
  
  const [cells, setCells] = useState<NotebookCell[]>([
      { id: 'cell_init', type: 'ingest', status: 'draft', timestamp: new Date().toISOString() }
  ]);

  const [history, setHistory] = useState<LineageEvent[]>([]);
  const [traeRecords, setTraeRecords] = useState<TraeRecord[]>([]);
  const [lineage, setLineage] = useState<LineageEntry[]>([]);

  // Helper to generate AI Understanding Summary
  const generateAIUnderstanding = (dataset: Dataset): AIUnderstanding => {
      const colNames = dataset.columns.map(c => c.name.toLowerCase());
      
      let domain = "General Purpose";
      if (colNames.some(c => c.includes('price') || c.includes('amount'))) domain = "Financial / Transactional";
      else if (colNames.some(c => c.includes('email') || c.includes('customer'))) domain = "CRM / Customer Data";
      else if (colNames.some(c => c.includes('sensor') || c.includes('device'))) domain = "IoT / Telemetry";

      const timeFields = dataset.columns.filter(c => c.type === 'datetime' || c.name.includes('date')).map(c => c.name);
      const keyIdentifiers = dataset.columns.filter(c => c.name.includes('id') || c.name.includes('key')).map(c => c.name);
      
      return {
          domainGuess: domain,
          rows: dataset.rowCount,
          columns: dataset.columns.length,
          keyIdentifiers,
          timeFields,
          targetVariable: colNames.includes('target') ? 'target' : colNames.includes('label') ? 'label' : 'Not inferred',
          concerns: ["Potential missing values", "Unverified duplicates"], // Mock for now
          confidence: 'Medium',
          userConfirmed: false
      };
  };

  const updateAIUnderstanding = (cellId: string, understanding: AIUnderstanding) => {
      setCells(prev => prev.map(c => c.id === cellId ? { ...c, aiUnderstanding: understanding } : c));
  };

  const confirmAIUnderstanding = (cellId: string) => {
      setCells(prev => {
          const cell = prev.find(c => c.id === cellId);
          if (!cell || !cell.aiUnderstanding) return prev;

          // 1. Mark as confirmed
          const updatedUnderstanding = { ...cell.aiUnderstanding, userConfirmed: true };
          
          // 2. Log to Lineage
          const lineageId = addLineageEntry({
              type: 'ai_action',
              description: `AI inferred domain: ${updatedUnderstanding.domainGuess}`,
              rationale: `Detected columns: ${cell.aiUnderstanding.keyIdentifiers.join(', ')}`,
              assumptions: [`Dataset is ${updatedUnderstanding.domainGuess}`],
              userApproved: true
          });

          return prev.map(c => c.id === cellId ? { 
              ...c, 
              aiUnderstanding: updatedUnderstanding,
              lineageId 
          } : c);
      });
  };

  // Helper to add Lineage Entry
  const addLineageEntry = (entry: Omit<LineageEntry, 'id' | 'timestamp'>): string => {
      const id = `lin_${Date.now()}`;
      const newEntry: LineageEntry = {
          id,
          timestamp: new Date().toISOString(),
          ...entry
      };
      setLineage(prev => [...prev, newEntry]);
      return id;
  };

  const addCell = (type: NotebookCell['type'], input?: string) => {
      // Auto-detect dependencies based on last active cell
      const lastCell = cells[cells.length - 1];
      const dependencies = lastCell ? [lastCell.id] : [];
      const timestamp = new Date().toISOString();

      // CLEANING WORKFLOW ENFORCEMENT
      if (type === 'clean') {
          // Instead of adding one generic 'clean' cell, add the 3-step sequence
          const profilingCell: NotebookCell = {
              id: `cell_${Date.now()}_prof`,
              type: 'profiling',
              status: 'done', // Auto-run immediate
              dependencies,
              timestamp,
              output: { loading: true } // Trigger auto-execution in view
          };

          const qualityCell: NotebookCell = {
              id: `cell_${Date.now()}_qual`,
              type: 'quality_check',
              status: 'done', // Auto-run immediate
              dependencies: [profilingCell.id],
              timestamp,
              output: { loading: true }
          };

          const recommendedPlan: ProposedPlan = {
              intent: "Clean data quality issues",
              rationale: "Detected missing values and duplicates.",
              proposed_steps: [
                  { step_id: 1, type: 'impute', description: "Impute missing 'customer_email' with 'unknown'", params: { column: 'customer_email', value: 'unknown' } },
                  { step_id: 2, type: 'drop_rows', description: "Remove 14 duplicate rows", params: {} },
                  { step_id: 3, type: 'impute', description: "Standardize 'price' column to numeric", params: { column: 'price', type: 'numeric' } }
              ],
              assumptions: [],
              risks: []
          };

          const planCell: NotebookCell = {
              id: `cell_${Date.now()}_plan`,
              type: 'cleaning_plan',
              status: 'draft', // User must approve
              dependencies: [qualityCell.id],
              timestamp,
              plan: recommendedPlan
          };

          setCells(prev => [...prev, profilingCell, qualityCell, planCell]);
          return;
      }

      // EDA WORKFLOW ENFORCEMENT
      if (type === 'eda') {
          // 1. EDA Context Cell (Read-Only, Auto-Run)
          const contextCell: NotebookCell = {
              id: `cell_${Date.now()}_eda_ctx`,
              type: 'eda_context',
              status: 'done',
              dependencies,
              timestamp
          };

          // 2. EDA Menu Cell (Action Selector)
          const menuCell: NotebookCell = {
              id: `cell_${Date.now()}_eda_menu`,
              type: 'eda_menu',
              status: 'draft', // Interactive
              dependencies: [contextCell.id],
              timestamp
          };

          setCells(prev => [...prev, contextCell, menuCell]);
          return;
      }

      // VALIDATION WORKFLOW ENFORCEMENT
      if (type === 'validation') {
          const ruleProposalCell: NotebookCell = {
              id: `cell_${Date.now()}_val_prop`,
              type: 'validation',
              status: 'suggested',
              dependencies,
              timestamp,
              plan: {
                  intent: "Data Validation",
                  rationale: "Proposing standard data quality checks.",
                  proposed_steps: [],
                  assumptions: [],
                  risks: []
              },
              input: "Propose validation rules"
          };
          setCells(prev => [...prev, ruleProposalCell]);
          return;
      }

      // SQL WORKFLOW ENFORCEMENT
      if (type === 'sql') {
           const sqlProposalCell: NotebookCell = {
              id: `cell_${Date.now()}_sql_prop`,
              type: 'sql',
              status: 'suggested',
              dependencies,
              timestamp,
              plan: {
                  intent: "SQL Query Generation",
                  rationale: "Drafting SQL query for user review.",
                  proposed_steps: [],
                  assumptions: [],
                  risks: []
              },
              input: "Draft SQL Query"
          };
          setCells(prev => [...prev, sqlProposalCell]);
          return;
      }

      const newCell: NotebookCell = {
          id: `cell_${Date.now()}`,
          type,
          input,
          status: 'draft',
          dependencies,
          timestamp
      };
      setCells(prev => [...prev, newCell]);
  };

  const updateCell = (id: string, updates: Partial<NotebookCell>) => {
      setCells(prev => {
          const newCells = prev.map(c => c.id === id ? { ...c, ...updates } : c);
          
          // Dependency Handling
          if (updates.output || (updates.status === 'done')) {
             const changedIndex = prev.findIndex(c => c.id === id);
             if (changedIndex !== -1) {
                 for (let i = changedIndex + 1; i < newCells.length; i++) {
                     if (newCells[i].status === 'done') {
                         newCells[i] = { ...newCells[i], status: 'stale' };
                     }
                 }
             }
          }
          return newCells;
      });
  };

  const approveCleaningPlan = (id: string, autoRun: boolean = false) => {
      setCells(prev => {
          const planCellIndex = prev.findIndex(c => c.id === id);
          if (planCellIndex === -1) return prev;
          
          const planCell = prev[planCellIndex];
          if (!planCell.plan) return prev;

          // 1. Mark plan as approved
          const updatedPlanCell = { ...planCell, status: 'approved' as const };
          
          // 2. Generate execution cells based on the plan
          const newExecutionCells: NotebookCell[] = planCell.plan.proposed_steps.map((step, idx) => ({
              id: `cell_${Date.now()}_step_${step.step_id}`,
              type: 'cleaning_step',
              status: autoRun ? 'done' : 'draft', // Auto-execute if requested
              input: step.description,
              dependencies: [planCell.id], // Depends on plan
              timestamp: new Date().toISOString(),
              plan: { ...planCell.plan!, proposed_steps: [step] } // Pass context for execution
          }));

          // 3. Insert new cells after the plan cell
          const newCells = [...prev];
          newCells[planCellIndex] = updatedPlanCell;
          newCells.splice(planCellIndex + 1, 0, ...newExecutionCells);
          
          return newCells;
      });
  };

  const deleteCell = (id: string) => {
      setCells(prev => prev.filter(c => c.id !== id));
  };

  const registerDataset = (dataset: Dataset, versionInfo?: { derivedFrom?: string, changes?: string[] }) => {
      const versionId = `v${Date.now()}`;
      
      // Auto-classify columns if not already done
      const classifiedColumns = dataset.columns.map(col => ({
          ...col,
          role: col.role || detectColumnRole(col.name, col.type)
      }));

      const enrichedDataset = { ...dataset, columns: classifiedColumns };

      const newVersion: DatasetVersion = {
          version: versionId,
          derived_from: versionInfo?.derivedFrom || null,
          changes: versionInfo?.changes || [],
          dataset: enrichedDataset
      };

      setDataState(prev => ({
          datasets: { ...prev.datasets, [dataset.name]: enrichedDataset },
          datasetVersions: { ...prev.datasetVersions, [versionId]: newVersion },
          activeDatasetId: dataset.name
      }));
  };

  const logToTrae = (record: TraeRecord) => {
      setTraeRecords(prev => [...prev, record]);
  };
  
  const updateColumnRole = (datasetName: string, columnName: string, newRole: any) => {
      setDataState(prev => {
          const dataset = prev.datasets[datasetName];
          if (!dataset) return prev;

          const updatedColumns = dataset.columns.map(c => c.name === columnName ? { ...c, role: newRole } : c);
          const updatedDataset = { ...dataset, columns: updatedColumns };

          return {
              ...prev,
              datasets: { ...prev.datasets, [datasetName]: updatedDataset }
          };
      });
  };

  // Expose methods in provider
  return (
    <DataContext.Provider value={{ dataState, cells, history, traeRecords, lineage, addCell, updateCell, deleteCell, registerDataset, logToTrae, approveCleaningPlan, generateAIUnderstanding, updateAIUnderstanding, confirmAIUnderstanding, addLineageEntry, updateColumnRole }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
