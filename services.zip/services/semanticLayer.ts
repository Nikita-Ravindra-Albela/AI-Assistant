import { Column, ColumnRole, ChartProposal, Dataset, EDAScope, EDAIntent } from '../types';

// 3. Mandatory Intelligence Layer
// A. Column Role Classification

export const detectColumnRole = (colName: string, dtype: string): ColumnRole => {
    const lowerName = colName.toLowerCase();
    
    // 1. Identifiers
    if (lowerName === 'id' || lowerName.endsWith('_id') || lowerName.endsWith('key') || lowerName === 'uuid') {
        return 'identifier';
    }

    // 2. Time
    if (dtype === 'datetime' || dtype === 'date' || lowerName.includes('date') || lowerName.includes('time') || lowerName === 'year' || lowerName === 'month') {
        return 'time';
    }

    // 3. Metrics (Additive vs Ratio)
    // Additive: amount, revenue, sales, price, cost, quantity, count
    if (['amount', 'revenue', 'sales', 'price', 'cost', 'quantity', 'count', 'profit', 'spend'].some(k => lowerName.includes(k))) {
        return 'metric_additive';
    }
    
    // Ratio: rate, percent, pct, ratio, avg, mean
    if (['rate', 'percent', 'pct', 'ratio', 'avg', 'mean', 'score', 'rating'].some(k => lowerName.includes(k))) {
        return 'metric_ratio';
    }

    // 4. Dimensions (Fallbacks)
    if (dtype === 'string' || dtype === 'category' || dtype === 'boolean') {
        return 'dimension';
    }

    // 5. Numeric Dimensions or Unknown Metrics
    if (['integer', 'float', 'number'].includes(dtype)) {
        // If it's numeric but not explicitly a metric name, it's ambiguous. 
        // Heuristic: Low cardinality numeric might be a dimension (e.g. status_code), high cardinality is likely a metric.
        // For now, default to metric_additive for safety in plotting, but flag as low confidence.
        return 'metric_additive'; 
    }

    return 'dimension'; // Default fallback
};

// C. Smart Aggregation Rules (Strict)
export const getSmartAggregation = (role: ColumnRole): 'sum' | 'mean' | 'count' | 'distinct' | 'none' => {
    switch (role) {
        case 'metric_additive': return 'sum';
        case 'metric_ratio': return 'mean';
        case 'identifier': return 'distinct';
        case 'dimension': return 'count';
        case 'time': return 'none'; 
        default: return 'count';
    }
};

// 4. Intent -> Constraint Map
export const EDA_CONSTRAINTS: Record<EDAIntent, any> = {
    distribution: {
        allowedCharts: ['histogram', 'density'],
        yAggregation: 'count',
        xRole: 'metric_additive', // Simplified to metric
        yRole: 'frequency'
    },
    magnitude: {
        allowedCharts: ['kpi', 'bar'],
        yAggregation: ['sum', 'mean'],
        xRole: 'none',
        yRole: 'metric_additive'
    },
    comparison: {
        allowedCharts: ['bar', 'box'],
        xRole: 'dimension',
        yRole: 'metric_additive',
        yAggregation: ['sum', 'mean']
    },
    trend: {
        allowedCharts: ['line'],
        xRole: 'time',
        yRole: 'metric_additive',
        yAggregation: ['sum', 'mean']
    },
    relationship: {
        allowedCharts: ['scatter'],
        xRole: 'metric_additive',
        yRole: 'metric_additive',
        yAggregation: 'none'
    },
    outliers: {
        allowedCharts: ['box'],
        xRole: 'metric_additive',
        yRole: 'value'
    },
    summary: {
        allowedCharts: ['table'],
        metrics: ['min', 'max', 'mean', 'median'],
        xRole: 'none',
        yRole: 'none',
        yAggregation: 'none'
    }
};

// 6. Axis Resolution Logic
const resolveXAxis = (dataset: Dataset, rules: any, preferredCol?: string): { column: string | null, role: ColumnRole | 'none' } => {
    // If preferred column provided, check if it matches role
    if (preferredCol) {
        const col = dataset.columns.find(c => c.name === preferredCol);
        if (col) {
            const role = col.role || detectColumnRole(col.name, col.type);
            // Loose check: if rule needs metric, accept metric_additive/ratio. If dimension, accept dimension/identifier.
            const matchesTime = rules.xRole === 'time' && role === 'time';
            const matchesDim = rules.xRole === 'dimension' && (role === 'dimension' || role === 'identifier');
            const matchesMetric = rules.xRole === 'metric_additive' && (role === 'metric_additive' || role === 'metric_ratio');
            
            if (matchesTime || matchesDim || matchesMetric || rules.xRole === 'none') {
                return { column: preferredCol, role: role };
            }
        }
    }

    // Auto-select based on rules
    if (rules.xRole === 'time') {
        const col = dataset.columns.find(c => (c.role || detectColumnRole(c.name, c.type)) === 'time');
        return col ? { column: col.name, role: 'time' } : { column: null, role: 'none' };
    }
    if (rules.xRole === 'dimension') {
        const col = dataset.columns.find(c => (c.role || detectColumnRole(c.name, c.type)) === 'dimension');
        return col ? { column: col.name, role: 'dimension' } : { column: null, role: 'none' };
    }
    if (rules.xRole === 'metric_additive') {
        const col = dataset.columns.find(c => (c.role || detectColumnRole(c.name, c.type)) === 'metric_additive');
        return col ? { column: col.name, role: 'metric_additive' } : { column: null, role: 'none' };
    }

    return { column: null, role: 'none' };
};

const resolveYAxis = (dataset: Dataset, rules: any, preferredCol?: string): { column: string | null, role: ColumnRole | 'frequency' | 'value' | 'none', aggregation: any } => {
    let agg = Array.isArray(rules.yAggregation) ? rules.yAggregation[0] : rules.yAggregation;
    
    if (rules.yRole === 'frequency') {
        return { column: 'Record Count', role: 'frequency', aggregation: 'count' };
    }

    if (preferredCol) {
        const col = dataset.columns.find(c => c.name === preferredCol);
        if (col) {
            const role = col.role || detectColumnRole(col.name, col.type);
             // Loose check
            const matchesMetric = (rules.yRole === 'metric_additive' || rules.yRole === 'value') && (role === 'metric_additive' || role === 'metric_ratio');
            
            if (matchesMetric) {
                return { column: preferredCol, role: role, aggregation: agg };
            }
        }
    }

    if (rules.yRole === 'metric_additive' || rules.yRole === 'value') {
         const col = dataset.columns.find(c => (c.role || detectColumnRole(c.name, c.type)) === 'metric_additive');
         return col ? { column: col.name, role: 'metric_additive', aggregation: agg } : { column: null, role: 'none', aggregation: 'none' };
    }

    return { column: null, role: 'none', aggregation: 'none' };
};

export const generateEDAProposal = (
    dataset: Dataset, 
    scope: EDAScope, 
    intent: EDAIntent,
    preferredX?: string,
    preferredY?: string
): ChartProposal => {
    const rules = EDA_CONSTRAINTS[intent];
    
    // Resolve Axes based on constraints + preferences
    const xAxis = resolveXAxis(dataset, rules, preferredX);
    const yAxis = resolveYAxis(dataset, rules, preferredY);

    return {
        scope,
        intent,
        chartType: rules.allowedCharts[0],
        xAxis,
        yAxis,
        rationale: `Selected ${rules.allowedCharts[0]} chart for ${intent} analysis. Constraints: X=${rules.xRole}, Y=${rules.yRole}.`,
        confidence: 'high',
        requiresConfirmation: true
    };
};

// Deprecated or Legacy (Keeping for now but pointing to new logic where possible)
export const generateChartProposal = (dataset: Dataset, xColName: string, yColName: string): ChartProposal => {
    // Attempt to infer intent from columns
    const xCol = dataset.columns.find(c => c.name === xColName);
    const yCol = dataset.columns.find(c => c.name === yColName);
    
    if (!xCol || !yCol) throw new Error("Invalid columns");

    const xRole = xCol.role || detectColumnRole(xCol.name, xCol.type);
    const yRole = yCol.role || detectColumnRole(yCol.name, yCol.type);

    let intent: EDAIntent = 'relationship'; // Default fallback
    let scope: EDAScope = 'bivariate';

    if (xRole === 'time') intent = 'trend';
    else if (xRole === 'dimension') intent = 'comparison';
    else if (xRole === 'metric_additive' && yRole === 'metric_additive') intent = 'relationship';
    
    return generateEDAProposal(dataset, scope, intent, xColName, yColName);
};

export const generateExplanation = (col1: string, col2: string, xRole: string, yRole: string, agg: string) => {
    return {
        xAxis: `${col1} (${xRole})`,
        yAxis: `${col2} (${agg.toUpperCase()})`,
        aggregation: agg.toUpperCase(),
        rationale: `Analyzing ${col1} vs ${col2}`,
        confidence: 'High' as const
    };
};

