import { ProposedPlan, Dataset, ExecutionOperation, QualityIssue, CleaningCell, ValidationResult } from '../types';

// Mock Engine Implementations
const runValidationEngine = (dataset: Dataset): ValidationResult[] => {
    // Structural, Statistical, Logical
    return [
        { ruleId: 'null_check', status: 'pass', violationCount: 0, violationPct: 0, sampleViolations: [] },
        { ruleId: 'schema_consistency', status: 'pass', violationCount: 0, violationPct: 0, sampleViolations: [] }
    ];
};

const runCleaningEngine = (dataset: Dataset, op: ExecutionOperation): { dataset: Dataset, issue: QualityIssue } => {
    // Detect -> Classify -> Suggest
    // Mocking a cleaning operation result
    return {
        dataset: { ...dataset, rowCount: dataset.rowCount }, // In real engine, this modifies data
        issue: {
            id: 'issue_1',
            column: op.params?.column || 'unknown',
            category: 'Missing Data',
            severity: 'medium',
            description: 'Found missing values',
            affected_rows: 5,
            affected_pct: 0.05,
            suggested_actions: []
        }
    };
};

const runSqlEngine = (query: string, datasets: Record<string, Dataset>) => {
    // Mock SQL execution
    // Deterministic, Schema-Aware
    return { rows: [], columns: [] };
};

export const executePlan = async (
    plan: ProposedPlan, 
    datasets: Record<string, Dataset>
): Promise<{ outputs: Record<string, Dataset>, logs: string[], validation: any }> => {
    
    const logs: string[] = [];
    const outputs: Record<string, Dataset> = {};
    const validation: any = {
        steps_validated: 0,
        warnings: []
    };
    
    logs.push(`Starting execution of intent: ${plan.intent}`);

    for (const op of plan.proposed_steps) {
        logs.push(`Executing Step ${op.step_id}: ${op.description}`);
        
        try {
            // 1. READ SCHEMA FIRST (MANDATORY)
            const inputDsName = op.params?.source || Object.keys(datasets)[0];
            const inputDs = datasets[inputDsName] || Object.values(outputs)[0];
            
            if (op.type !== 'load_csv' && !inputDs) {
                 logs.push(`WARN: No input dataset found for operation ${op.type}. Skipping schema check.`);
            } else if (inputDs) {
                 logs.push(`Schema Context: ${inputDs.columns.map(c => c.name).join(', ')}`);
            }

            // 2. EXECUTE BASED ON TYPE
            if (op.type === 'load_csv') {
                const limit = op.params?.limit || 10;
                const totalRows = 1245;
                const rowsToGenerate = limit === -1 ? totalRows : Math.min(limit, totalRows);
                
                logs.push(`DuckDB: Loading CSV into memory (Arrow Table)...`);
                
                const newDataset: Dataset = {
                    name: op.name || 'sales_data',
                    rows: Array.from({ length: rowsToGenerate }).map((_, i) => ({
                        order_id: `ORD-${1000+i}`,
                        customer_email: i % 3 === 0 ? null : `user${i}@example.com`,
                        amount: (Math.random() * 1000).toFixed(2),
                        status: ['Shipped', 'Pending', 'Delivered', 'Cancelled'][i % 4],
                        created_at: new Date().toISOString()
                    })),
                    columns: [
                        { name: 'order_id', type: 'string' },
                        { name: 'customer_email', type: 'string' },
                        { name: 'amount', type: 'float' },
                        { name: 'status', type: 'category' },
                        { name: 'created_at', type: 'datetime' }
                    ],
                    rowCount: totalRows
                };
                outputs[op.name || 'sales_data'] = newDataset;
                logs.push(`PyArrow: Schema inferred successfully. ${newDataset.rows.length} rows cached.`);
            } 
            
            else if (op.type === 'create_table') {
                // SQL Generation Engine
                const newDataset: Dataset = {
                    name: op.name || 'new_table',
                    rows: [], 
                    columns: [],
                    rowCount: 0
                };
                outputs[newDataset.name] = newDataset;
                logs.push(`DuckDB: Created table ${newDataset.name}`);
            }

            else if (op.type === 'impute') {
                // Cleaning Engine
                if (inputDs) {
                    const { issue } = runCleaningEngine(inputDs, op);
                    logs.push(`Cleaning Engine: Detected ${issue.category} in ${issue.column}. Applied fix via Vectorized Operation.`);
                }
            }
            
            else if (op.type === 'sql_query') {
                // SQL Engine
                logs.push(`DuckDB Executing: ${op.query}`);
                // In real app, runSqlEngine(op.query, datasets)
            }

            // 3. MANDATORY VALIDATION AFTER EVERY STEP
            if (inputDs || outputs[op.name || '']) {
                 const target = outputs[op.name || ''] || inputDs;
                 const validationResults = runValidationEngine(target);
                 const failures = validationResults.filter(r => r.status === 'fail');
                 
                 if (failures.length > 0) {
                     logs.push(`CRITICAL: Validation failed with ${failures.length} errors.`);
                     throw new Error(`Validation failed: ${failures[0].ruleId}`);
                 } else {
                     logs.push(`Validation passed: ${validationResults.length} checks OK.`);
                     validation.steps_validated++;
                 }
            }

        } catch (e: any) {
            logs.push(`ERROR in Step ${op.step_id}: ${e.message}`);
            throw e;
        }
    }

    return { outputs, logs, validation };
};
